/* Cross-platform, one process serves the compiled page, API and Socket.IO. */
const {spawn}=require('node:child_process');
const fs=require('node:fs');
const path=require('node:path');
const net=require('node:net');
const os=require('node:os');
const root=path.resolve(__dirname,'..');
process.chdir(root);
function run(command,args){return new Promise((resolve,reject)=>{const child=spawn(command,args,{cwd:root,stdio:'inherit',windowsHide:true});child.on('error',reject);child.on('exit',code=>code===0?resolve():reject(new Error(`${command} exited with ${code}`)));});}
function npm(args){return process.platform==='win32'?run(process.env.ComSpec||'cmd.exe',['/d','/c','npm',...args]):run('npm',args);}
function freePort(port){return new Promise((resolve,reject)=>{const test=net.createServer();test.once('error',()=>reject(new Error(`Port ${port} is already in use. Close the other ChargeQuest window, or set a different PORT in .env.`)));test.listen(port,()=>test.close(resolve));});}
async function main(){
 const [major,minor]=process.versions.node.split('.').map(Number);
 if(major<20||(major===20&&minor<19))throw new Error('Please install Node.js 22.12 or newer, then run START_WINDOWS.cmd again.');
 console.log('\nChargeQuest — complete A + B + C classroom\n');
 if(!fs.existsSync('node_modules/express')||!fs.existsSync('node_modules/vite')){console.log('First launch: installing dependencies. Internet access is needed.');await npm(['ci','--include=dev']);}
 require(path.join(root,'node_modules','dotenv')).config({path:path.join(root,'.env')});
 const port=Number(process.env.PORT||3001);if(!Number.isInteger(port)||port<1||port>65535)throw new Error('PORT must be a number between 1 and 65535.');
 await freePort(port);
 console.log('\nBuilding the combined application…');await npm(['run','build']);
 console.log(`\nOpen http://localhost:${port}\nKeep this window open. Press Ctrl+C to stop.\n`);
 if(!process.env.AI_API_KEY||!process.env.AI_BASE_URL||!process.env.AI_MODEL)console.log('AI credentials are not set. Guided fallback is active; the full classroom still works.\n');
 for(const list of Object.values(os.networkInterfaces()))for(const address of list||[])if(address.family==='IPv4'&&!address.internal)console.log(`Same Wi-Fi only: http://${address.address}:${port} (your firewall must allow this port)`);
 const child=spawn(process.execPath,['dist/server/index.js'],{cwd:root,stdio:'inherit',env:process.env,windowsHide:true});
 child.on('error',e=>{console.error(e.message);process.exitCode=1;});child.on('exit',code=>{process.exitCode=code||0;});
 const timer=setTimeout(()=>{
  const url=`http://localhost:${port}`;
  if(process.env.CHARGEQUEST_NO_OPEN==='1')return;
  if(process.platform==='win32')spawn('explorer.exe',[url],{windowsHide:true,stdio:'ignore'}).on('error',()=>{});
  else if(process.platform==='darwin')spawn('open',[url],{stdio:'ignore'}).on('error',()=>{});
 },900);timer.unref();
 process.on('SIGINT',()=>{child.kill('SIGINT');});process.on('SIGTERM',()=>{child.kill('SIGTERM');});
}
main().catch(error=>{console.error('\n'+error.message);process.exitCode=1;});
