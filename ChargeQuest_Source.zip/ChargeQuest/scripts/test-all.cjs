const fs=require('node:fs');
const {spawnSync}=require('node:child_process');
const path=require('node:path');
const root=path.resolve(__dirname,'..');
const files=['server','tests'].flatMap(dir=>fs.readdirSync(path.join(root,dir)).filter(name=>name.endsWith('.test.ts')).map(name=>`${dir}/${name}`));
const result=spawnSync(process.execPath,['--import','tsx','--test',...files],{cwd:root,stdio:'inherit',windowsHide:true});
if(result.error)console.error(result.error.message);process.exitCode=result.status??1;
