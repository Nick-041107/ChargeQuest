const fs=require('node:fs');for(const n of ['research.cjs','researchPhysics.cjs'])fs.copyFileSync('server/'+n,'dist/server/'+n);
