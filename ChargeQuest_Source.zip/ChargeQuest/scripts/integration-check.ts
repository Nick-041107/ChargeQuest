/**
 * ChargeQuest - automated two-device integration check. Owner: B.
 *
 * Simulates 1 host + 2 students over real HTTP + Socket.IO and verifies the
 * acceptance list from Handoff v2 section 10. Replaces manual clicking for
 * the first integration round; a real phone check is still required for the
 * public HTTPS deployment.
 *
 * Run (backend must already be running on PORT=3001):
 *   npx tsx scripts/integration-check.ts
 */

import { io, type Socket } from 'socket.io-client';
import type {
  Ack,
  Aggregate,
  ClientSession,
  PrivateSession,
  RoomSnapshot,
  SessionResults,
  TutorDecision,
} from '../shared/contracts';

const BASE = process.env.CHECK_BASE_URL ?? 'http://localhost:3001';
let passed = 0;
let failed = 0;

function errOf(r: Ack): string {
  return r.ok ? '' : r.error;
}

function check(label: string, condition: boolean, detail = ''): void {
  if (condition) {
    passed += 1;
    console.log(`  PASS  ${label}`);
  } else {
    failed += 1;
    console.log(`  FAIL  ${label}${detail ? ` -> ${detail}` : ''}`);
  }
}

async function post<T>(url: string, body: unknown, token?: string): Promise<T> {
  const res = await fetch(`${BASE}${url}`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: JSON.stringify(body),
  });
  const json = (await res.json()) as Ack<T>;
  if (!json.ok) throw new Error(`${url}: ${json.error}`);
  return json.data;
}

type Client = {
  label: string;
  session: ClientSession;
  socket: Socket;
  snapshot: RoomSnapshot | null;
  priv: PrivateSession | null;
  results: SessionResults | null;
};

function connect(label: string, session: ClientSession): Promise<Client> {
  return new Promise((resolve, reject) => {
    const c: Client = {
      label, session, socket: io(BASE, {
        auth: { roomCode: session.roomCode, token: session.token },
        transports: ['websocket'],
      }),
      snapshot: null, priv: null, results: null,
    };
    let settled = false;
    const timer = setTimeout(() => {
      if (!settled) { settled = true; reject(new Error(`${label} connect timeout`)); }
    }, 5000);
    c.socket.on('room:snapshot', (s: RoomSnapshot) => {
      if (!c.snapshot || s.revision >= c.snapshot.revision) c.snapshot = s;
      // Resolve only once the first snapshot has actually arrived.
      if (!settled) { settled = true; clearTimeout(timer); resolve(c); }
    });
    c.socket.on('session:private', (p: PrivateSession) => { c.priv = p; });
    c.socket.on('session:results', (r: SessionResults) => { c.results = r; });
    c.socket.on('connect_error', (e) => {
      if (!settled) { settled = true; clearTimeout(timer); reject(e); }
    });
  });
}

function emit(c: Client, event: string, payload: unknown): Promise<Ack> {
  return new Promise((resolve) => {
    c.socket.emit(event, payload, (r: Ack) => resolve(r));
  });
}

const wait = (ms: number) => new Promise((r) => setTimeout(r, ms));

async function main(): Promise<void> {
  console.log(`\nChargeQuest integration check against ${BASE}\n`);

  const health = await fetch(`${BASE}/api/health`).then((r) => r.json());
  check('GET /api/health returns ok', (health as { ok: boolean }).ok === true);

  const room = await post<{ code: string; hostToken: string }>('/api/rooms', {});
  check('create room returns a 6-digit code', /^\d{6}$/.test(room.code), room.code);

  const j1 = await post<{ participantId: string; studentToken: string }>(
    `/api/rooms/${room.code}/join`, { nickname: 'Alice' });
  const j2 = await post<{ participantId: string; studentToken: string }>(
    `/api/rooms/${room.code}/join`, { nickname: 'Bob' });

  const host = await connect('host', {
    role: 'host', token: room.hostToken, participantId: null, roomCode: room.code,
  });
  const alice = await connect('student Alice', {
    role: 'student', token: j1.studentToken, participantId: j1.participantId, roomCode: room.code,
  });
  const bob = await connect('student Bob', {
    role: 'student', token: j2.studentToken, participantId: j2.participantId, roomCode: room.code,
  });
  await wait(150);

  check('1 host + 2 students see the same room',
    [host, alice, bob].every((c) => c.snapshot?.code === room.code));
  check('snapshot shows 2 participants, no tokens',
    host.snapshot?.participants.length === 2 &&
    !JSON.stringify(host.snapshot).includes(room.hostToken));

  // A student must not be able to control the class.
  const forged = await emit(alice, 'host:set_stage', { stage: 'predict_rc' });
  check('forged host event from a student is rejected', forged.ok === false, errOf(forged));
  check('forged event did not change the stage', host.snapshot?.stage === 'lobby');

  const stage = await emit(host, 'host:set_stage', { stage: 'predict_rc' });
  check('host can open predict_rc stage', stage.ok === true);

  const opened = await emit(host, 'host:open_question', { questionId: 'rc_v1' });
  check('host opens rc_v1', opened.ok === true);
  await wait(120);
  check('aggregate is hidden while question is open',
    host.snapshot?.aggregate === null && bob.snapshot?.aggregate === null);
  check('submittedCount starts at 0', host.snapshot?.submittedCount === 0);

  const wrongStage = await emit(host, 'host:open_question', { questionId: 'final_v1' });
  check('question must match the current stage', wrongStage.ok === false);

  const a1 = await emit(alice, 'student:submit', {
    questionId: 'rc_v1', optionId: 'half', explanation: 'Half becomes heat.', confidence: 80,
  });
  const b1 = await emit(bob, 'student:submit', {
    questionId: 'rc_v1', optionId: 'all', explanation: 'Energy is conserved.', confidence: 60,
  });
  check('two different answers accepted', a1.ok && b1.ok);
  await wait(150);
  check('submittedCount is 2', host.snapshot?.submittedCount === 2);

  // Overwrite: repeated submission must not increase the count.
  await emit(alice, 'student:submit', {
    questionId: 'rc_v1', optionId: 'all', explanation: 'Changed my mind.', confidence: 50,
  });
  await wait(150);
  check('re-submitting overwrites, count stays 2', host.snapshot?.submittedCount === 2);

  const badOption = await emit(bob, 'student:submit', {
    questionId: 'rc_v1', optionId: 'nonsense', explanation: 'x', confidence: 50,
  });
  check('invalid option id is rejected', badOption.ok === false);

  // Late joiner spectates this question only.
  const j3 = await post<{ participantId: string; studentToken: string }>(
    `/api/rooms/${room.code}/join`, { nickname: 'Late' });
  const late = await connect('late joiner', {
    role: 'student', token: j3.studentToken, participantId: j3.participantId, roomCode: room.code,
  });
  await wait(120);
  const lateTry = await emit(late, 'student:submit', {
    questionId: 'rc_v1', optionId: 'half', explanation: 'late', confidence: 50,
  });
  check('late joiner cannot answer the open question', lateTry.ok === false, errOf(lateTry));
  check('late joiner is told they spectate',
    late.priv?.eligibleQuestionIds.includes('rc_v1') === false);

  const closed = await emit(host, 'host:close_question', {});
  check('host closes the question', closed.ok === true);
  await wait(150);
  const agg = host.snapshot?.aggregate as Aggregate | null;
  check('aggregate becomes public after close', agg !== null);
  check('aggregate counts are correct (all:2, eligible:2)',
    agg?.counts?.all === 2 && agg?.eligible === 2, JSON.stringify(agg));
  check('raw explanations never enter the public snapshot',
    !JSON.stringify(host.snapshot).includes('Half becomes heat') &&
    !JSON.stringify(host.snapshot).includes('Changed my mind'));

  const afterClose = await emit(alice, 'student:submit', {
    questionId: 'rc_v1', optionId: 'half', explanation: 'too late', confidence: 50,
  });
  check('no edits after close', afterClose.ok === false);

  // AI tutor with no key -> deterministic Guided fallback.
  const decision = await post<TutorDecision>(
    `/api/rooms/${room.code}/tutor`, {}, room.hostToken);
  check('tutor returns a decision without any AI key', !!decision.message);
  check('fallback is explicitly labelled', decision.source === 'fallback');
  const unauthorized = await fetch(`${BASE}/api/rooms/${room.code}/tutor`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}',
  });
  check('tutor endpoint rejects a missing host token', unauthorized.status === 403);

  const applied = await emit(host, 'host:apply_tutor', {});
  check('host can Apply the decision', applied.ok === true);
  await wait(150);
  check('tutor appears in the public snapshot only after Apply',
    host.snapshot?.tutor?.message === decision.message);

  // Reconnect restores identity and state.
  alice.socket.disconnect();
  const alice2 = await connect('Alice reconnected', alice.session);
  await wait(150);
  check('refresh/reconnect restores the room snapshot',
    alice2.snapshot?.code === room.code && alice2.snapshot.revision > 0,
    JSON.stringify({ code: alice2.snapshot?.code, rev: alice2.snapshot?.revision }));
  // The fallback chose ask_followup, so Apply opened a followup question and
  // correctly cleared the aggregate. Reconnect must still restore my own data.
  check('reconnect restores my own submission',
    alice2.priv?.mySubmissions.some((s) => s.questionId === 'rc_v1') === true);

  // Final question + paired results. Use alice2: alice's socket was closed
  // above, but it is the SAME participantId so the paired sample still works.
  await emit(host, 'host:set_stage', { stage: 'final_check' });
  const finalOpen = await emit(host, 'host:open_question', { questionId: 'final_v1' });
  check('host opens final_v1 in final_check', finalOpen.ok === true, errOf(finalOpen));
  await wait(120);
  check('final_check fixes V0=8', host.snapshot?.experiment.params.V0 === 8);
  const finalSubmit = await emit(alice2, 'student:submit', {
    questionId: 'final_v1', optionId: 'a', explanation: 'Same fraction, lower voltage.', confidence: 90,
  });
  check('student can answer the final question', finalSubmit.ok === true, errOf(finalSubmit));
  await emit(host, 'host:close_question', {});
  await emit(host, 'host:set_stage', { stage: 'results' });
  await wait(250);
  check('paired results only count students with both answers',
    host.snapshot?.stage === 'results' && alice2.results !== null && alice2.results.pairedCount === 1,
    JSON.stringify(alice2.results));
  check('paired results report pre/post correct counts',
    alice2.results?.preCorrect === 0 && alice2.results?.postCorrect === 1,
    JSON.stringify(alice2.results));
  check('no fake mastery percentage is produced',
    !JSON.stringify(alice2.results).includes('mastery'));

  for (const c of [host, alice, bob, late, alice2]) c.socket.disconnect();

  console.log(`\n${passed} passed, ${failed} failed\n`);
  if (failed > 0) process.exitCode = 1;
}

const watchdog = setTimeout(() => {
  console.error('\nIntegration check timed out after 30s');
  process.exit(1);
}, 30_000);

main()
  .catch((err) => {
    console.error('\nIntegration check crashed:', err);
    process.exitCode = 1;
  })
  .finally(() => {
    clearTimeout(watchdog);
    // socket.io-client keeps handles alive; exit explicitly once checks finish.
    setTimeout(() => process.exit(failed > 0 ? 1 : 0), 50);
  });
