const fs=require('node:fs');const path=require('node:path');
const root=path.resolve(__dirname,'..');
try{const state=JSON.parse(fs.readFileSync(path.join(root,'.public-share-state.json'),'utf8'));if(!Number.isInteger(state.ownerPid))throw new Error('No public sharing session');fs.writeFileSync(path.join(root,'.public-share-stop.json'),JSON.stringify({ownerPid:state.ownerPid}));console.log('Requested public sharing to stop. The local classroom can keep running.');}catch{console.log('No active public sharing session was found.');}
