// Starts the prebuilt release using the Node runtime shipped in this Windows package.
const path=require('node:path');
const fs=require('node:fs');
const net=require('node:net');
const os=require('node:os');
const {spawn}=require('node:child_process');
const root=path.resolve(__dirname,'..');process.chdir(root);
try{require('dotenv').config({path:path.join(root,'.env')});}catch{console.error('Dependencies are missing. Extract the entire zip before launching.');process.exit(1);}
const port=Number(process.env.PORT||3001);
if(!Number.isInteger(port)||port<1||port>65535){console.error('PORT in .env must be between 1 and 65535.');process.exit(1);}
if(!fs.existsSync('dist/server/index.js')||!fs.existsSync('client/dist/index.html')){console.error('The built application is missing. Extract the entire release package.');process.exit(1);}
const probe=net.createServer();probe.once('error',()=>{console.error(`Port ${port} is occupied. Close the previous ChargeQuest window, or change PORT in .env.`);process.exitCode=1;});
probe.listen(port,()=>probe.close(()=>{
 console.log('\nChargeQuest — complete classroom\n');
 console.log(`Open http://localhost:${port}\nKeep this window open. Closing it stops the classroom.\n`);
 console.log('Students must join before the host opens a question. Restarting clears all rooms.');
 for(const list of Object.values(os.networkInterfaces()))for(const address of list||[])if(address.family==='IPv4'&&!address.internal)console.log(`Same Wi-Fi: http://${address.address}:${port} (allow the port in your firewall)`);
 if(!process.env.AI_API_KEY||!process.env.AI_BASE_URL||!process.env.AI_MODEL)console.log('AI mode: Guided fallback. To enable online AI, configure the three AI_* values in .env.');
 const child=spawn(process.execPath,['dist/server/index.js'],{cwd:root,env:process.env,stdio:'inherit',windowsHide:true});
 child.on('error',e=>{console.error(e.message);process.exitCode=1;});child.on('exit',code=>{process.exitCode=code||0;});
 const ready=setInterval(async()=>{
  try{if(!(await fetch(`http://localhost:${port}/api/health`)).ok)return;clearInterval(ready);if(process.env.CHARGEQUEST_NO_OPEN!=='1')spawn('explorer.exe',[`http://localhost:${port}`],{windowsHide:true,stdio:'ignore'}).on('error',()=>{});}catch{}
 },300);ready.unref();
 process.on('SIGINT',()=>child.kill('SIGINT'));process.on('SIGTERM',()=>child.kill('SIGTERM'));
}));
