const {spawnSync}=require('node:child_process');
const path=require('node:path');
const root=path.resolve(__dirname,'..');
const result=spawnSync(process.execPath,['node_modules/typescript/bin/tsc','--noEmit','--strict','--skipLibCheck','--jsx','react-jsx','--esModuleInterop','--moduleResolution','bundler','--module','esnext','--target','es2022','--lib','es2022,dom','client/src/main.tsx'],{cwd:root,stdio:'inherit',windowsHide:true});
if(result.error)console.error(result.error.message);process.exitCode=result.status??1;
