// Optional temporary public sharing. Does not restart an existing classroom.
const fs=require('node:fs');const path=require('node:path');const {spawn}=require('node:child_process');
const root=path.resolve(__dirname,'..');process.chdir(root);
try{require('dotenv').config({path:path.join(root,'.env')});}catch{}
const port=Number(process.env.PORT||3001),local=`http://127.0.0.1:${port}`;
const stateFile=path.join(root,'.public-share-state.json'),stopFile=path.join(root,'.public-share-stop.json');
const metaFiles=[path.join(root,'client/dist/public-access.json'),path.join(root,'client/public/public-access.json')];
const binary=path.join(root,'runtime/cloudflared.exe');
let tunnel,ownedServer,origin='',heartbeat,stopTimer,stopping=false,publishing=false,ready=false;
function read(file){try{return JSON.parse(fs.readFileSync(file,'utf8'));}catch{return null;}}
function write(file,data){fs.mkdirSync(path.dirname(file),{recursive:true});const tmp=file+'.tmp';fs.writeFileSync(tmp,JSON.stringify(data));fs.renameSync(tmp,file);}
async function health(base){try{const res=await fetch(base+'/api/health',{signal:AbortSignal.timeout(8000),cache:'no-store'});const body=await res.json();return res.ok&&body?.ok&&body.data?.status==='ok';}catch{return false;}}
function openLocal(){if(!process.argv.includes('--no-open')&&process.env.CHARGEQUEST_NO_OPEN!=='1')spawn('explorer.exe',[`http://localhost:${port}`],{windowsHide:true,stdio:'ignore'}).on('error',()=>{});}
function publish(){const meta={origin,expiresAt:Date.now()+90000};for(const file of metaFiles)write(file,meta);write(stateFile,{...meta,ownerPid:process.pid,tunnelPid:tunnel?.pid});}
function clearMeta(){for(const file of metaFiles){if(read(file)?.origin===origin)try{fs.unlinkSync(file);}catch{}}if(read(stateFile)?.ownerPid===process.pid)try{fs.unlinkSync(stateFile);}catch{}}
function stop(){if(stopping)return;stopping=true;clearInterval(heartbeat);clearInterval(stopTimer);clearMeta();if(tunnel)tunnel.kill();if(ownedServer)ownedServer.kill();if(read(stopFile)?.ownerPid===process.pid)try{fs.unlinkSync(stopFile);}catch{};console.log('Public sharing stopped.');}
async function establish(){
 if(publishing||!origin||stopping)return;publishing=true;
 const deadline=Date.now()+75000;
 for(let attempt=0;Date.now()<deadline&&!stopping;attempt++){
  if(await health(origin)){
   ready=true;publish();fs.writeFileSync(path.join(root,'PUBLIC_JOIN_URL.txt'),`ChargeQuest temporary public address:\r\n${origin}\r\n\r\nRefresh your existing host page to update its QR code.\r\nKeep the classroom and public sharing running. The address changes when the tunnel restarts.\r\n`);
   console.log(`\nPublic HTTPS ready: ${origin}\nRefresh the current host page. Its QR code will use this address.\nKeep the classroom and public sharing running.\n`);openLocal();
   heartbeat=setInterval(async()=>{if(stopping)return;if(await health(local)&&await health(origin))publish();else clearMeta();},15000);heartbeat.unref();return;
  }
  if(attempt===0||attempt%10===0)console.log('Waiting for the new public hostname to become reachable…');
  await new Promise(resolve=>setTimeout(resolve,1500));
 }
 if(!ready){console.error('Tunnel started but its public health check failed. Check logs/public-tunnel.log and try again.');stop();process.exitCode=1;}
}
async function main(){
 if(!Number.isInteger(port)||port<1||port>65535)throw new Error('Invalid PORT in .env.');
 const existing=read(stateFile);
 if(existing?.expiresAt>Date.now()&&await health(existing.origin)){console.log(`Public sharing is already running: ${existing.origin}\nRefresh the host page. Use STOP_PUBLIC_WINDOWS.cmd to stop sharing.`);openLocal();return;}
 if(!fs.existsSync(binary))throw new Error('runtime/cloudflared.exe is missing. Use the updated complete package.');
 if(!(await health(local))){
  console.log('Starting the bundled classroom…');
  ownedServer=spawn(process.execPath,['scripts/start-bundled.cjs'],{cwd:root,env:{...process.env,CHARGEQUEST_NO_OPEN:'1'},windowsHide:true,stdio:'inherit'});
  let started=false;for(let i=0;i<40;i++){if(await health(local)){started=true;break;}await new Promise(resolve=>setTimeout(resolve,250));}
  if(!started)throw new Error('The local classroom could not start.');
 }
 console.log('Starting temporary public HTTPS sharing. No account is required.');
 fs.mkdirSync(path.join(root,'logs'),{recursive:true});
 const log=fs.createWriteStream(path.join(root,'logs/public-tunnel.log'),{flags:'a'});
 tunnel=spawn(binary,['tunnel','--url',local,'--protocol','http2','--no-autoupdate'],{cwd:root,windowsHide:true,stdio:['ignore','pipe','pipe']});
 let recent='';
 const onLog=chunk=>{log.write(chunk);recent=(recent+chunk.toString()).slice(-12000);const match=recent.match(/https:\/\/[a-z0-9-]+\.trycloudflare\.com/);if(match&&!origin){origin=match[0];void establish();}};
 tunnel.stdout.on('data',onLog);tunnel.stderr.on('data',onLog);
 tunnel.on('error',error=>{console.error(error.message);stop();process.exitCode=1;});
 tunnel.on('exit',code=>{if(!stopping){console.error(`Public tunnel stopped (${code}). Start START_PUBLIC_WINDOWS.cmd again.`);stop();process.exitCode=1;}log.end();});
 stopTimer=setInterval(()=>{if(read(stopFile)?.ownerPid===process.pid)stop();},1000);stopTimer.unref();
 const startupTimeout=setTimeout(()=>{if(!ready&&!stopping){console.error('Timed out starting public sharing. See logs/public-tunnel.log.');stop();process.exitCode=1;}},120000);startupTimeout.unref();
 process.on('SIGINT',stop);process.on('SIGTERM',stop);
}
main().catch(error=>{console.error(error.message);stop();process.exitCode=1;});
