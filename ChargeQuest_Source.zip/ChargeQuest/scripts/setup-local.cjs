'use strict';
// Run inside the extracted ChargeQuest_Agent_Edition folder using installed Node.
const fs=require('node:fs'),path=require('node:path');
const root=process.cwd();
if(!fs.existsSync(path.join(root,'dist/server/research.cjs'))){console.error('Open PowerShell inside ChargeQuest_Agent_Edition (the folder with START_WINDOWS.cmd), then run this file.');process.exit(1);}
const pending=[];
for(const rel of ['server/research.cjs','dist/server/research.cjs']){
 const p=path.join(root,rel);let s=fs.readFileSync(p,'utf8');
 if(!s.includes('CHARGEQUEST_LOCAL_OLLAMA')){
  const needle="const res=await fetch(url,{";
  if(!s.includes(needle))throw Error('Unsupported research module version; nothing has been written.');
  const local=`// CHARGEQUEST_LOCAL_OLLAMA: actual on-device inference, not canned responses.
 if((url.hostname==='127.0.0.1'||url.hostname==='localhost')&&url.port==='11434'){
  const localMessages=messages.map(m=>({...m,content:m.role==='system'?m.content+' Use compact JSON. For a plan use exactly TWO cases. Keep commentary short.':m.content}));
  const rr=await fetch(url.origin+'/api/chat',{method:'POST',headers:{'Content-Type':'application/json'},signal:AbortSignal.any([signal,AbortSignal.timeout(180000)]),body:JSON.stringify({model,messages:localMessages,stream:false,format:'json',keep_alive:'20m',options:{temperature:0.1,num_predict:1200,num_ctx:4096}})});
  if(!rr.ok)throw Error('Local model HTTP '+rr.status+'. Check ollama pull qwen2.5:3b and that Ollama is running.');
  const bb=await rr.json();const answer=bb.message?.content||'';
  try{return JSON.parse(answer.trim().replace(/^\x60\x60\x60(?:json)?\\s*/,'').replace(/\\s*\x60\x60\x60$/,''));}catch{throw Error('Local model returned incomplete JSON. Retry a narrower experiment question.');}
 }
 `;
  s=s.replace(needle,local+needle);
  s=s.replace('const maxRounds=Math.max(1,Math.min(2,Number(req.body.maxRounds)||2));','const maxRounds=Math.max(1,Math.min(Number(process.env.AGENT_LOCAL_ROUNDS)||2,2,Number(req.body.maxRounds)||2));');
 }
 pending.push([p,s]);
}
for(const rel of ['server/ai.ts','dist/server/ai.js']){const p=path.join(root,rel);if(fs.existsSync(p)){let s=fs.readFileSync(p,'utf8');s=s.replace('const TIMEOUT_MS = 12_000;',"const TIMEOUT_MS = process.env.AI_BASE_URL?.includes('11434') ? 180_000 : 12_000;");pending.push([p,s]);}}
for(const [p,s] of pending){if(!fs.existsSync(p+'.before-local'))fs.copyFileSync(p,p+'.before-local');fs.writeFileSync(p,s);}
const envPath=path.join(root,'.env');let env=fs.existsSync(envPath)?fs.readFileSync(envPath,'utf8'):'';
if(fs.existsSync(envPath)&&!fs.existsSync(envPath+'.before-local'))fs.copyFileSync(envPath,envPath+'.before-local');
for(const [key,value]of Object.entries({AI_API_KEY:'ollama',AI_BASE_URL:'http://127.0.0.1:11434/v1',AI_MODEL:'qwen2.5:3b',AGENT_LOCAL_ROUNDS:'1'})){
 const re=new RegExp('^'+key+'=.*$','m');if(re.test(env))env=env.replace(re,key+'='+value);else env+='\n'+key+'='+value;
}
fs.writeFileSync(envPath,env.trim()+'\n');
console.log('Local model configured: qwen2.5:3b on this PC. No cloud key required.');
console.log('Download model once: ollama pull qwen2.5:3b');
console.log('Warm up: ollama run qwen2.5:3b "Reply with just OK."');
console.log('Then restart ChargeQuest: node scripts/start-bundled.cjs');
console.log('Use Agent research lab -> Ask the agent. Default: one short research round for the deadline.');
console.log('To allow two rounds later, set AGENT_LOCAL_ROUNDS=2 in .env and restart.');
console.log('The legacy classroom Analyze button has a shorter browser wait; use Agent research lab for local inference.');
