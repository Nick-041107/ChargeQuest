import { sampleRC, sampleLC, getTiming, initialEnergy, steadyStateRC, energyBalance } from './physics';
import type { PhysicsParams } from './physics';
import type { PhysicsSample } from './physics';

export type ExperimentState = {
  mode: 'rc' | 'lc'; status: 'idle' | 'running' | 'paused' | 'finished';
  params: PhysicsParams; simTime: number; updatedAt: number;
  playbackRate: number; stopAtFirstZero: boolean; runId: number;
};
export function experimentDuration(e: ExperimentState): number {
  const timing = getTiming(e.mode, e.params);
  return e.mode === 'lc' && e.stopAtFirstZero ? timing.firstZero! : timing.duration;
}
export function timeAt(e: ExperimentState, now: number, clockOffsetMs = 0): number {
  const delta = e.status === 'running' ? Math.max(0, now + clockOffsetMs - e.updatedAt) / 1000 * e.playbackRate : 0;
  return Math.max(0, Math.min(experimentDuration(e), e.simTime + delta));
}
const f = (x: number, digits = 2) => (Math.abs(x) < 1e-10 ? 0 : x).toFixed(digits);
const svgText = (x: number, y: number, value: string, extra = '') => `<text x="${x}" y="${y}" ${extra}>${value}</text>`;

/** Generates only trusted SVG/HTML from validated numeric circuit data. No student text enters here. */
export function circuitSVG(e: ExperimentState, t: number): string {
  const s = e.mode === 'rc' ? sampleRC(e.params, t) : sampleLC(e.params, t);
  const opened = e.status === 'idle' || (e.mode === 'lc' && e.stopAtFirstZero && t >= experimentDuration(e) - 1e-12);
  if (opened) s.i = 0;
  const flow = !opened && Math.abs(s.i) > 1e-7;
  const color = s.i < 0 ? '#2563a6' : '#b84139';
  const component = e.mode === 'rc'
    ? '<path d="M340 100 l10 -11 14 22 14 -22 14 22 14 -22 14 22 14 -22 10 11"/>'
    : '<path d="M340 100 c0 -24 26 -24 26 0 c0 -24 26 -24 26 0 c0 -24 26 -24 26 0 c0 -24 26 -24 26 0"/>';
  const theta = (e.mode === 'lc' ? Math.PI / getTiming('lc', e.params).firstZero! : 1 / (e.params.R * e.params.C / 2)) * t;
  const direction = s.i < 0 ? -1 : 1;
  const particles = flow ? [0,1,2,3,4].map(k => {
    const x = 474 + ((theta * 37 * direction + k * 29) % 145 + 145) % 145;
    return `<path d="M${x - direction * 5} 95 l${direction * 7} 5 l${-direction * 7} 5" fill="none" stroke="${color}" stroke-width="2.2"/>`;
  }).join('') : '';
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 355" role="img" aria-label="${e.mode.toUpperCase()} circuit, two capacitors with switch and ${e.mode === 'rc' ? 'resistor' : 'inductor'}">
  <rect x="28" y="132" width="206" height="140" rx="12" fill="#fdf6f4"/>
  <rect x="566" y="132" width="206" height="140" rx="12" fill="#f1f7fc"/>
  <g fill="none" stroke="#263745" stroke-width="1.9" stroke-linejoin="round" stroke-linecap="round">
  <path d="M170 188 V100 H260 M305 100 H340 M444 100 H630 V188 M170 210 V295 H630 V210"/>
  <path d="M146 188 H194 M146 210 H194 M606 188 H654 M606 210 H654" stroke-width="2.8"/>
  ${component}
  <circle cx="260" cy="100" r="3.5" fill="white"/><circle cx="305" cy="100" r="3.5" fill="white"/>
  <path d="M264 99 L301 ${opened ? 75 : 99}" stroke-width="2.2"/>
  <path d="M400 295 V310 M384 310 H416 M389 317 H411 M395 324 H405"/>
  </g>
  ${flow ? `<path d="M170 177 V100 H254 M311 100 H334 M450 100 H630 V177 M630 221 V295 H170 V221" stroke="${color}" stroke-width="5" opacity="0.13" fill="none"/>` : ''}${particles}
  <g font-family="Georgia, 'Times New Roman', serif" fill="#263745" font-size="21">
  ${svgText(282, 57, 'S', 'text-anchor="middle"')}
  ${svgText(392, 57, e.mode === 'rc' ? `R = ${f(e.params.R, 0)} Ω` : `L = ${f(e.params.L * 1000, 0)} mH`, 'text-anchor="middle"')}
  ${svgText(57, 174, 'C<tspan baseline-shift="sub" font-size="14">A</tspan>')}${svgText(690, 174, 'C<tspan baseline-shift="sub" font-size="14">B</tspan>')}
  ${svgText(45, 204, `${f(e.params.C * 1e6, 0)} μF`, 'font-size="16"')}${svgText(680, 204, `${f(e.params.C * 1e6, 0)} μF`, 'font-size="16"')}
  ${svgText(185, 170, '+', 'font-size="17"')}${svgText(185, 238, '−', 'font-size="17"')}${svgText(645, 170, '+', 'font-size="17"')}${svgText(645, 238, '−', 'font-size="17"')}
  </g>
  <g font-family="system-ui,sans-serif">
  <rect x="244" y="148" width="130" height="82" rx="9" fill="white" stroke="#edccc7"/>
  <rect x="426" y="148" width="130" height="82" rx="9" fill="white" stroke="#c4daee"/>
  ${svgText(309, 173, 'V<tspan baseline-shift="sub" font-size="9">A</tspan>', 'text-anchor="middle" font-size="13" fill="#8f4b44"')}${svgText(309, 214, `${f(s.vA)} V`, 'text-anchor="middle" font-size="20" font-weight="600" fill="#b84139"')}
  ${svgText(491, 173, 'V<tspan baseline-shift="sub" font-size="9">B</tspan>', 'text-anchor="middle" font-size="13" fill="#477391"')}${svgText(491, 214, `${f(s.vB)} V`, 'text-anchor="middle" font-size="20" font-weight="600" fill="#2563a6"')}
  ${svgText(548, 135, `i = ${f(s.i * 1000, 1)} mA`, `text-anchor="middle" font-size="15" fill="${color}"`)}
  ${svgText(400, 256, opened ? (t > 0 ? 'OPEN · energy held in B' : 'OPEN · initially charged') : 'CLOSED · transient response', 'text-anchor="middle" font-size="12" fill="#697786"')}
  </g></svg>`;
}

export function waveSVG(e: ExperimentState, t: number): string {
  const end = experimentDuration(e), sample = e.mode === 'rc' ? sampleRC : sampleLC;
  const current = sample(e.params, t);
  const idle = e.status === 'idle';
  const opened = e.mode === 'lc' && e.stopAtFirstZero && t >= end - 1e-12;
  const volts = Math.max(e.params.V0, 1);
  const peakA = e.mode === 'rc' ? e.params.V0 / e.params.R : e.params.V0 * Math.sqrt(e.params.C / (2 * e.params.L));
  const peak = Math.max(peakA * 1000, 1);
  const floorI = e.mode === 'lc' ? -peak : 0;
  const left = 82, right = 862, width = right - left;
  const x = (time: number) => left + width * time / end;
  const yv = (v: number) => 67 + 155 * (1 - v / volts);
  const yi = (mA: number) => 355 + 155 * (peak - mA) / (peak - floorI);
  const cursor = x(t);
  const samples = Array.from({length:201}, (_, k) => sample(e.params, end*k/200));
  const done = samples.filter(s => s.t < t);
  done.push(current);
  const path = (list:PhysicsSample[], key:'vA'|'vB'|'i') => list.map((s,k)=>`${k?'L':'M'}${f(x(s.t))},${f(key==='i'?yi(s.i*1000):yv(s[key]))}`).join(' ');
  const currentY = yi(idle || opened ? 0 : current.i * 1000);
  const voltageGrid = Array.from({length:5},(_,k)=>{
    const v=volts*k/4, y=yv(v);
    return `<path d="M${left} ${y} H${right}" stroke="#e5ecf1"/>${svgText(left-14,y+4,f(v,volts%4===0?0:1),'text-anchor="end"')}`;
  }).join('');
  const currentGrid = Array.from({length:5},(_,k)=>{
    const v=floorI+(peak-floorI)*k/4, y=yi(v);
    return `<path d="M${left} ${y} H${right}" stroke="${Math.abs(v)<1e-9?'#a6b7c3':'#e5ecf1'}"/>${svgText(left-14,y+4,f(v,peak<10?1:0),'text-anchor="end"')}`;
  }).join('');
  const timeTicks = [0,1,2,3,4].map(k=>{
    const time=end*k/4, px=x(time);
    return [ [67,222,251], [355,510,539] ].map(([top,bottom,label])=>`<path d="M${px} ${top} V${bottom}" stroke="#e5ecf1"/><path d="M${px} ${bottom} v5" stroke="#aebec9"/>${svgText(px,label,f(time*1000,2),'text-anchor="middle"')}`).join('');
  }).join('');
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 920 580" data-cq-wave="true" role="img" aria-label="Separate voltage and current plots with five calibrated ticks per axis and current readings">
  <g font-family="system-ui,sans-serif">
  <rect x="1" y="1" width="918" height="276" rx="12" fill="#fbfcfd" stroke="#e3eaf0"/>
  <rect x="1" y="289" width="918" height="283" rx="12" fill="#fbfcfd" stroke="#e3eaf0"/>
  <g font-size="12" fill="#607587">${voltageGrid}${currentGrid}${timeTicks}</g>
  <g fill="#263e50" font-size="16" font-weight="600">${svgText(22,31,'Capacitor voltage')}${svgText(22,319,'Transfer current')}</g>
  <g fill="#6c7f8d" font-size="11">${svgText(24,56,'V')}${svgText(20,344,'mA')}${svgText(455,269,'Time (ms)','text-anchor="middle"')}${svgText(455,557,'Time (ms)','text-anchor="middle"')}</g>
  <g font-size="14" font-weight="600">
  ${svgText(555,31,`— V<tspan baseline-shift="sub" font-size="10">A</tspan>  ${f(current.vA)} V`,'fill="#b84139"')}${svgText(725,31,`— V<tspan baseline-shift="sub" font-size="10">B</tspan>  ${f(current.vB)} V`,'fill="#2563a6"')}
  ${svgText(640,319,`— i  ${f((idle||opened?0:current.i)*1000,2)} mA`,'fill="#397c6a"')}
  </g>
  <path d="M${left} 67 V222 H${right} M${left} 355 V510 H${right}" stroke="#acbdc9" fill="none"/>
  <path d="${path(samples,'vA')}" stroke="#b84139" opacity="0.12" fill="none" stroke-width="2" stroke-dasharray="4 5"/>
  <path d="${path(samples,'vB')}" stroke="#2563a6" opacity="0.12" fill="none" stroke-width="2" stroke-dasharray="4 5"/>
  <path d="${path(samples,'i')}" stroke="#397c6a" opacity="0.12" fill="none" stroke-width="2" stroke-dasharray="4 5"/>
  ${!idle ? `<path d="${path(done,'vA')}" stroke="#b84139" fill="none" stroke-width="3"/><path d="${path(done,'vB')}" stroke="#2563a6" fill="none" stroke-width="3"/><path d="${path(done,'i')}" stroke="#397c6a" fill="none" stroke-width="2.8"/>` : ''}
  <path d="M${cursor} 67 V222 M${cursor} 355 V510" stroke="#6e8495" stroke-dasharray="4 4" opacity="0.65"/>
  <circle cx="${cursor}" cy="${yv(current.vA)}" r="4.5" fill="#b84139" stroke="white" stroke-width="1.5"/>
  <circle cx="${cursor}" cy="${yv(current.vB)}" r="4.5" fill="#2563a6" stroke="white" stroke-width="1.5"/>
  <circle cx="${cursor}" cy="${currentY}" r="4.5" fill="#397c6a" stroke="white" stroke-width="1.5"/>
  </g><g data-cq-probe="true" style="display:none;pointer-events:none"></g></svg>`;
}
export function energyMarkup(s: PhysicsSample, initial: number): string {
  const entries = [ ['Capacitor A', s.eA, '#b84139'], ['Capacitor B', s.eB, '#2563a6'], ['Inductor', s.eL, '#397c6a'], ['Heat', s.heat, '#c58c2e'] ] as const;
  return `<div class="cq-exp-energy">${entries.map(([label, value, color]) => `<div class="cq-exp-energy-row"><div><span>${label}</span><strong>${f(value * 1000, 3)} mJ</strong></div><div class="cq-exp-track"><div style="width:${initial > 0 ? Math.max(0, Math.min(100, value / initial * 100)) : 0}%;background:${color}"></div></div></div>`).join('')}</div>`;
}
export function experimentMarkup(e: ExperimentState, t: number): string {
  const sample = (e.mode === 'rc' ? sampleRC : sampleLC)(e.params, t);
  const e0 = initialEnergy(e.params), balance = energyBalance(e.params, sample);
  const limit = steadyStateRC(e.params);
  const stopped = e.mode === 'lc' && e.stopAtFirstZero && t >= experimentDuration(e) - 1e-12;
  return `<div class="cq-exp-grid"><section class="cq-exp-card"><div class="cq-exp-eyebrow">${e.mode === 'rc' ? 'RESISTIVE CHARGE SHARING' : 'IDEAL RESONANT TRANSFER'}</div>${circuitSVG(e,t)}
  <div class="cq-exp-footnote">Initial charge only · no connected supply ${e.mode === 'lc' ? '· ideal lossless model' : '· R includes the connection resistance'}</div></section>
  <section class="cq-exp-card"><div class="cq-exp-eyebrow">ENERGY ACCOUNT · initial ${f(e0 * 1000, 3)} mJ</div>${energyMarkup(sample,e0)}<div class="cq-exp-balance">Stored + heat = ${f(balance.accounted * 1000, 3)} mJ <span>Energy conserved</span></div></section>
  <section class="cq-exp-card cq-exp-waves"><div class="cq-exp-wave-heading"><div class="cq-exp-eyebrow">TIME RESPONSE · t = ${f(t * 1000, 3)} ms</div><span class="cq-exp-wave-help">Hover to inspect · solid = elapsed · dashed = model reference</span></div><div class="cq-exp-wave-scroll">${waveSVG(e,t)}</div></section>
  <section class="cq-exp-card cq-exp-insight"><div class="cq-exp-eyebrow">WHAT TO NOTICE</div><h3>${e.mode === 'rc' ? 'Charge is shared. Energy is dissipated.' : stopped ? 'Open at zero current. Hold the transfer.' : 'Store energy temporarily in a magnetic field.'}</h3>
  <p>${e.mode === 'rc' ? 'Changing R changes the peak current and the duration, but not the final heat for this initial condition.' : 'The inductor exchanges energy with both capacitors. Without opening the switch, the energy flows back.'}</p>
  ${e.mode === 'rc' ? `<div class="cq-exp-limit"><strong>Steady-state limit</strong><br>V<sub>A</sub> = V<sub>B</sub> = ${f(limit.vA)} V<br>Total retained: 50% · Delivered to B: 25%<br>Heat: ${f(limit.heat * 1000, 3)} mJ</div>` : `<div class="cq-exp-limit"><strong>First non-initial zero-current instant</strong><br>t* = ${f(getTiming('lc',e.params).firstZero! * 1000,3)} ms<br>V<sub>A</sub> = 0 V · V<sub>B</sub> = ${f(e.params.V0)} V<br>Ideal energy delivered to B: 100%</div>`}
  <p class="cq-exp-footnote">${e.mode === 'rc' ? 'The card shows the mathematical limit; finite-time curves approach it continuously.' : 'Real components have losses. This ideal model does not predict actual 100% efficiency.'}</p></section></div>`;
}


/** Independent model probe: never modifies room state, time or circuit parameters. */
export function probeTimeAt(e: ExperimentState, svgX: number): number {
  return Math.max(0, Math.min(1, (svgX - 82) / 780)) * experimentDuration(e);
}
export function probeMarkup(e: ExperimentState, time: number, svgY = 90): string {
  const end = experimentDuration(e);
  const t = Math.max(0, Math.min(end, time));
  const s = (e.mode === 'rc' ? sampleRC : sampleLC)(e.params, t);
  const x = 82 + 780 * t / end;
  const volts = Math.max(e.params.V0, 1);
  const peak = Math.max(1, 1000 * (e.mode === 'rc' ? e.params.V0 / e.params.R : e.params.V0 * Math.sqrt(e.params.C / (2 * e.params.L))));
  const bottom = e.mode === 'lc' ? -peak : 0;
  const yA = 67 + 155 * (1 - s.vA / volts), yB = 67 + 155 * (1 - s.vB / volts);
  const yI = 355 + 155 * (peak - s.i * 1000) / (peak - bottom);
  const boxX = Math.max(10, Math.min(648, x > 570 ? x - 282 : x + 18));
  const boxY = Math.max(8, Math.min(302, svgY + 18));
  const rows: [string,string,string][] = [
    ['V<tspan baseline-shift="sub" font-size="9">A</tspan>', `${f(s.vA,3)} V`, '#b84139'],
    ['V<tspan baseline-shift="sub" font-size="9">B</tspan>', `${f(s.vB,3)} V`, '#2563a6'],
    ['Current A → B', `${f(s.i*1000,3)} mA`, '#397c6a'],
    ['Energy · capacitor A', `${f(s.eA*1000,4)} mJ`, '#b84139'],
    ['Energy · capacitor B', `${f(s.eB*1000,4)} mJ`, '#2563a6'],
    ['Energy · inductor', `${f(s.eL*1000,4)} mJ`, '#397c6a'],
    ['Cumulative heat', `${f(s.heat*1000,4)} mJ`, '#a77621'],
    ['Total accounted', `${f((s.eA+s.eB+s.eL+s.heat)*1000,4)} mJ`, '#334d60'],
  ];
  return `<g pointer-events="none" font-family="system-ui,sans-serif">
  <path d="M${x} 67 V222 M${x} 355 V510" stroke="#293e50" stroke-width="1.5" stroke-dasharray="5 4"/>
  ${[[yA,'#b84139'],[yB,'#2563a6'],[yI,'#397c6a']].map(([y,c])=>`<circle cx="${x}" cy="${y}" r="5" fill="${c}" stroke="white" stroke-width="2"/>`).join('')}
  <rect x="${boxX+2}" y="${boxY+3}" width="262" height="260" rx="9" fill="#193247" opacity="0.12"/>
  <rect x="${boxX}" y="${boxY}" width="262" height="260" rx="9" fill="white" stroke="#a9bdca"/>
  ${svgText(boxX+14,boxY+22,`t = ${f(t*1000,4)} ms`,'font-size="15" font-weight="700" fill="#233e52"')}
  ${svgText(boxX+14,boxY+40,'MODEL PROBE · playback unchanged','font-size="9" letter-spacing="0.6" fill="#748796"')}
  <path d="M${boxX+14} ${boxY+49} h234" stroke="#e2e9ef"/>
  ${rows.map(([label,value,color],k)=>`${svgText(boxX+14,boxY+71+k*24,label,'font-size="11" fill="#536e81"')}${svgText(boxX+248,boxY+71+k*24,value,`text-anchor="end" font-size="12" font-weight="600" fill="${color}"`)}`).join('')}
  </g>`;
}
export function clearWaveProbe(root: Element): void {
  const probe = root.querySelector('[data-cq-probe]');
  if (probe) probe.setAttribute('style', 'display:none;pointer-events:none');
}
export function applyWaveProbe(root: Element, e: ExperimentState, clientX: number, clientY: number): void {
  const svg = root.querySelector('[data-cq-wave]');
  const probe = svg?.querySelector('[data-cq-probe]');
  if (!svg || !probe) return;
  const rect = svg.getBoundingClientRect();
  if (rect.width <= 0 || rect.height <= 0) return;
  const x = (clientX - rect.left) / rect.width * 920;
  const y = (clientY - rect.top) / rect.height * 580;
  if (x < 82 || x > 862 || y < 60 || y > 555) { clearWaveProbe(root); return; }
  probe.innerHTML = probeMarkup(e, probeTimeAt(e,x), y);
  probe.setAttribute('style','display:block;pointer-events:none');
}
