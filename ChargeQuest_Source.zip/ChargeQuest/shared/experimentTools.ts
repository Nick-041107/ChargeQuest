import { DEFAULT_PARAMS, sampleRC, sampleLC, getTiming, initialEnergy, steadyStateRC } from './physics';
import type { ExperimentState } from './experimentView';
import { experimentDuration } from './experimentView';

export type ExperimentToolCommand =
  | { action: 'compare_resistance'; values: [number, number]; claim?: string; question?: string }
  | { action: 'inspect_time'; timeMs: number; highlight: 'current' | 'voltage' | 'heat' | 'energy' }
  | { action: 'clear_tools' };
export type ExperimentToolsState = {
  comparison: { values: [number, number] } | null;
  focusTime: number | null;
  highlight: 'current' | 'voltage' | 'heat' | 'energy' | null;
  task: { claim: string; question: string; source: 'ai' | 'manual' } | null;
};
export const emptyTools = (): ExperimentToolsState => ({ comparison: null, focusTime: null, highlight: null, task: null });

/** Validate on the server too. This function neither calls a model nor trusts AI-generated code. */
export function validateToolCommand(input: unknown): ExperimentToolCommand {
  if (!input || typeof input !== 'object') throw new Error('Tool command must be an object');
  const c = input as Record<string, unknown>;
  if (c.action === 'clear_tools') return { action: 'clear_tools' };
  if (c.action === 'compare_resistance') {
    if (!Array.isArray(c.values) || c.values.length !== 2 || c.values.some(v => typeof v !== 'number' || !Number.isFinite(v) || v < 10 || v > 1000)) throw new Error('Provide two resistances between 10 and 1000 ohms');
    if (c.values[0] === c.values[1]) throw new Error('Choose two different resistances');
    for (const key of ['claim', 'question']) if (c[key] !== undefined && (typeof c[key] !== 'string' || (c[key] as string).length > 500)) throw new Error(`${key} must be text of at most 500 characters`);
    return { action: c.action, values: [c.values[0], c.values[1]], claim: c.claim as string | undefined, question: c.question as string | undefined };
  }
  if (c.action === 'inspect_time') {
    if (typeof c.timeMs !== 'number' || !Number.isFinite(c.timeMs) || c.timeMs < 0) throw new Error('timeMs must be finite and nonnegative');
    if (!['current','voltage','heat','energy'].includes(c.highlight as string)) throw new Error('Invalid probe highlight');
    return { action: c.action, timeMs: c.timeMs, highlight: c.highlight as 'current' | 'voltage' | 'heat' | 'energy' };
  }
  throw new Error('Unknown experiment tool');
}

/** Server-side reducer. Server supplies source, timestamp and authoritative state. */
export function executeExperimentTool(
  current: ExperimentState, tools: ExperimentToolsState, input: unknown,
  options: { now: number; source: 'ai' | 'manual' },
) {
  const command = validateToolCommand(input);
  if (!Number.isFinite(options.now)) throw new Error('Server timestamp required');
  if (!['ai','manual'].includes(options.source)) throw new Error('Invalid trusted source');
  if (command.action === 'clear_tools') return { experiment: current, tools: emptyTools(), result: { action: command.action } };
  if (command.action === 'compare_resistance') {
    const values: [number,number] = [...command.values];
    const params = { ...current.params, R: Math.max(...values) };
    const duration = getTiming('rc', params).duration;
    const experiment: ExperimentState = { ...current, mode: 'rc', params, status: 'running', simTime: 0,
      updatedAt: options.now, playbackRate: duration / 8, stopAtFirstZero: false, runId: current.runId + 1 };
    const next: ExperimentToolsState = { comparison: { values }, focusTime: null, highlight: null, task: {
      claim: command.claim ?? 'A smaller resistance produces less total heat.',
      question: command.question ?? 'Change only resistance. Compare peak current, transient duration and final heat.',
      source: options.source,
    } };
    return { experiment, tools: next, result: {
      action: command.action, model: 'equal-capacitor RC', units: 'SI', sharedDuration: duration,
      initialEnergy: initialEnergy(params),
      cases: values.map(R => ({ R, tau: R * params.C / 2, peakCurrent: params.V0 / R, final: steadyStateRC({ ...params, R }) })),
    } };
  }
  const t = command.timeMs / 1000;
  if (t > experimentDuration(current)) throw new Error('Probe time exceeds experiment duration');
  const next = { ...tools, focusTime: t, highlight: command.highlight };
  const params = tools.comparison ? tools.comparison.values.map(R => ({ ...current.params, R })) : [current.params];
  return { experiment: current, tools: next, result: { action: command.action, units: 'SI', time: t,
    samples: params.map(p => ({ R: p.R, ...(current.mode === 'rc' ? sampleRC(p, t) : sampleLC(p, t)) })) } };
}

export function makeDemoExperiment(now: number): ExperimentState {
  return { mode: 'rc', status: 'idle', params: { ...DEFAULT_PARAMS }, simTime: 0, updatedAt: now, playbackRate: 0.05/8, stopAtFirstZero: true, runId: 0 };
}
