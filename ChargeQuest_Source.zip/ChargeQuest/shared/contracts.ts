/**
 * ChargeQuest - FROZEN SHARED CONTRACT
 * Owner: B (backend). Everyone else: READ ONLY.
 * Source of truth: Team Handoff v2 (2026-11-07), sections 4 and 13.
 *
 * Any change here must be announced to A and C at the same time.
 * All physical values are SI units: F, V, ohm, H, s, A, J.
 * Convert to uF / mA / mJ only for display.
 */

export type Stage =
  | 'lobby'
  | 'predict_rc'
  | 'reveal_rc'
  | 'resistance'
  | 'lc'
  | 'final_check'
  | 'results';

export type Role = 'host' | 'student';

export type PhysicsParams = {
  C: number;
  V0: number;
  R: number;
  L: number;
};

export type PhysicsSample = {
  t: number;
  vA: number;
  vB: number;
  i: number;
  eA: number;
  eB: number;
  eL: number;
  heat: number;
};

export type Question = {
  id: string;
  kind: 'rc_energy' | 'resistance_loss' | 'followup' | 'final';
  prompt: string;
  options: { id: string; label: string }[];
  requiresExplanation: boolean;
};

export type Submission = {
  participantId: string;
  questionId: string;
  optionId: string | null;
  explanation: string;
  confidence: number;
  submittedAt: number;
};

export type Aggregate = {
  submitted: number;
  eligible: number;
  counts: Record<string, number>;
};

export type TutorAction =
  | 'ask_followup'
  | 'retry_experiment'
  | 'explain'
  | 'advance_lc'
  | 'final_check';

export type TutorDecision = {
  source: 'ai' | 'fallback';
  misconception: string;
  evidence: string;
  message: string;
  action: TutorAction;
  followup: string | null;
};

export type ExperimentState = {
  mode: 'rc' | 'lc';
  status: 'idle' | 'running' | 'paused' | 'finished';
  params: PhysicsParams;
  simTime: number;
  updatedAt: number;
  playbackRate: number;
  stopAtFirstZero: boolean;
  runId: number;
};

export type RoomSnapshot = {
  code: string;
  revision: number;
  serverNow: number;
  stage: Stage;
  participants: { id: string; nickname: string; connected: boolean }[];
  question: Question | null;
  questionOpen: boolean;
  aggregate: Aggregate | null;
  submittedCount: number;
  experiment: ExperimentState;
  tutor: TutorDecision | null;
};

export type ClientSession = {
  role: Role;
  token: string;
  participantId: string | null;
  roomCode: string;
};

export type Ack<T = undefined> =
  | { ok: true; data: T }
  | { ok: false; error: string };

/* ------------------------------------------------------------------ *
 * Section 13 additions - part of the frozen contract
 * ------------------------------------------------------------------ */

export type PrivateSession = {
  mySubmissions: Submission[];
  eligibleQuestionIds: string[];
};

export type SessionResults = {
  mySubmissions: Submission[];
  pairedCount: number;
  preCorrect: number;
  postCorrect: number;
};

export type ExperimentPanelProps = {
  experiment: ExperimentState;
  clockOffsetMs: number;
  role: Role;
  onControl?: (command: 'play' | 'pause' | 'reset') => void;
  onParamsChange?: (params: PhysicsParams) => void;
  onStopAtFirstZeroChange?: (enabled: boolean) => void;
};

/** Input for the AI tutor. Student prose is untrusted data. */
export type TutorInput = {
  stage: Stage;
  question: Question;
  aggregate: Aggregate;
  explanations: string[];
  params: PhysicsParams;
  physicsFacts: string;
  previousDecisions: TutorDecision[];
  answerVersion: number;
};

/** Payload carried in Socket.IO handshake auth. Never put tokens in the URL. */
export type SocketAuth = {
  roomCode: string;
  token: string;
};

/* ------------------------------------------------------------------ *
 * Event payloads
 * ------------------------------------------------------------------ */

export type HostSetStagePayload = { stage: Stage };
export type HostOpenQuestionPayload = { questionId: string };
export type HostSetExperimentPayload = {
  mode: 'rc' | 'lc';
  params: PhysicsParams;
  stopAtFirstZero: boolean;
};
export type HostExperimentControlPayload = {
  command: 'play' | 'pause' | 'reset';
};
export type StudentSubmitPayload = {
  questionId: string;
  optionId: string | null;
  explanation: string;
  confidence: number;
};

/* ------------------------------------------------------------------ *
 * Fixed constants (safe to import from the client)
 * ------------------------------------------------------------------ */

export const DEFAULT_PARAMS: PhysicsParams = {
  C: 100e-6,
  V0: 10,
  R: 100,
  L: 10e-3,
};

export const FINAL_CHECK_PARAMS: PhysicsParams = {
  C: 100e-6,
  V0: 8,
  R: 100,
  L: 10e-3,
};

export const R_MIN = 10;
export const R_MAX = 1000;
export const MAX_STUDENTS = 30;
export const MAX_EXPLANATION = 500;
export const NICKNAME_MIN = 1;
export const NICKNAME_MAX = 24;
