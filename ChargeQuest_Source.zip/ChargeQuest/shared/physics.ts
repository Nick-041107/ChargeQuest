/** Pure circuit calculations. SI units throughout; no React or network dependencies. */
export type PhysicsParams = { C: number; V0: number; R: number; L: number };
export type PhysicsSample = {
  t: number; vA: number; vB: number; i: number;
  eA: number; eB: number; eL: number; heat: number;
};
export const DEFAULT_PARAMS: Readonly<PhysicsParams> = Object.freeze({
  C: 100e-6, V0: 10, R: 100, L: 10e-3,
});

function positive(value: number, name: string): void {
  if (!Number.isFinite(value) || value <= 0) throw new RangeError(`${name} must be finite and positive`);
}
function validate(p: PhysicsParams, t = 0): void {
  positive(p.C, 'C'); positive(p.R, 'R'); positive(p.L, 'L');
  if (!Number.isFinite(p.V0) || p.V0 < 0) throw new RangeError('V0 must be finite and nonnegative');
  if (!Number.isFinite(t) || t < 0) throw new RangeError('t must be finite and nonnegative');
  if (!Number.isFinite(p.C * p.V0 ** 2 / 2)) throw new RangeError('Initial energy exceeds numeric range');
}
export function initialEnergy(p: PhysicsParams): number {
  validate(p); return p.C * p.V0 ** 2 / 2;
}
export function getTiming(mode: 'rc' | 'lc', p: PhysicsParams): {
  duration: number; firstZero: number | null;
} {
  validate(p);
  if (mode === 'rc') {
    const tau = p.R * p.C / 2;
    positive(tau, 'RC time constant'); positive(10 * tau, 'RC duration');
    return { duration: 10 * tau, firstZero: null };
  }
  if (mode !== 'lc') throw new RangeError('Mode must be rc or lc');
  const firstZero = Math.PI * Math.sqrt(p.L * p.C / 2);
  positive(firstZero, 'LC first zero'); positive(2 * firstZero, 'LC duration');
  return { duration: 2 * firstZero, firstZero };
}
export function sampleRC(p: PhysicsParams, t: number): PhysicsSample {
  validate(p, t);
  const { C, V0, R } = p;
  const tau = getTiming('rc', p).duration / 10;
  const x = Math.exp(-t / tau);
  const vA = V0 * (1 + x) / 2;
  const vB = V0 * (1 - x) / 2;
  const e0 = C * V0 ** 2 / 2;
  return {
    t, vA, vB, i: V0 * x / R,
    eA: C * vA ** 2 / 2, eB: C * vB ** 2 / 2, eL: 0,
    // expm1 avoids cancellation for very small elapsed times.
    heat: e0 / 2 * -Math.expm1(-2 * t / tau),
  };
}
/** Exact asymptotic state, for a labelled steady-state card, not a finite-time curve. */
export function steadyStateRC(p: PhysicsParams): Omit<PhysicsSample, 't'> {
  validate(p); const e0 = initialEnergy(p);
  return { vA: p.V0 / 2, vB: p.V0 / 2, i: 0, eA: e0 / 4, eB: e0 / 4, eL: 0, heat: e0 / 2 };
}
/** Ideal lossless LC; keeps oscillating unless the caller freezes time at firstZero. */
export function sampleLC(p: PhysicsParams, t: number): PhysicsSample {
  validate(p, t);
  const firstZero = getTiming('lc', p).firstZero!;
  const omega = Math.PI / firstZero;
  const phase = omega * t;
  const vA = p.V0 * (1 + Math.cos(phase)) / 2;
  const vB = p.V0 * (1 - Math.cos(phase)) / 2;
  const i = p.V0 * p.C * omega * Math.sin(phase) / 2;
  return { t, vA, vB, i, eA: p.C * vA ** 2 / 2, eB: p.C * vB ** 2 / 2, eL: p.L * i ** 2 / 2, heat: 0 };
}
export function energyBalance(p: PhysicsParams, s: PhysicsSample): {
  initial: number; accounted: number; absoluteError: number; relativeError: number;
} {
  const initial = initialEnergy(p);
  const accounted = s.eA + s.eB + s.eL + s.heat;
  const absoluteError = Math.abs(accounted - initial);
  return { initial, accounted, absoluteError, relativeError: initial === 0 ? absoluteError : absoluteError / initial };
}
