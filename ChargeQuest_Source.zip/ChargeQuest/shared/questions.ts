/**
 * ChargeQuest - public question bank. Owner: B. Content reviewed by C (Nick).
 *
 * IMPORTANT: correct answers are NOT here. They live only in
 * server/questionsAnswerKey.ts (server-side). Never ship an answer key
 * to the browser bundle.
 *
 * Option IDs are part of the frozen contract. Do not rename them.
 * Question text is English (UI language). Followup is created by Apply
 * with an empty option list, so it is not in this bank.
 */

import type { Question, Stage } from './contracts';

export const RC_V1: Question = {
  id: 'rc_v1',
  kind: 'rc_energy',
  prompt:
    'Two identical capacitors (100 uF each) are connected through a resistor. Capacitor A starts at 10 V and B at 0 V. After the circuit fully settles, how much of the initial stored energy remains in the two capacitors combined?',
  options: [
    { id: 'quarter', label: 'One quarter (25%)' },
    { id: 'half', label: 'One half (50%)' },
    { id: 'all', label: 'All of it (100%)' },
    { id: 'unsure', label: 'Not sure yet' },
  ],
  requiresExplanation: true,
};

export const RESISTANCE_V1: Question = {
  id: 'resistance_v1',
  kind: 'resistance_loss',
  prompt:
    'We reduce the resistor from 100 ohm to 10 ohm and repeat the same experiment. After it settles, how does the total heat dissipated compare with the first run?',
  options: [
    { id: 'less', label: 'Less heat' },
    { id: 'same', label: 'The same heat' },
    { id: 'more', label: 'More heat' },
    { id: 'unsure', label: 'Not sure yet' },
  ],
  requiresExplanation: true,
};

export const FINAL_V1: Question = {
  id: 'final_v1',
  kind: 'final',
  prompt:
    'Two identical 100 uF capacitors now start at 8 V and 0 V. After the RC connection settles, what are the final voltages and the retained energy fraction? In your explanation, also say why adding an ideal inductor and opening the switch at the first zero-current instant gives a different result.',
  options: [
    { id: 'a', label: 'Both at 4 V, 50% of the initial energy retained' },
    { id: 'b', label: 'Both at 4 V, 100% of the initial energy retained' },
    { id: 'c', label: 'Both at 8 V, 100% of the initial energy retained' },
    { id: 'd', label: 'Not sure yet' },
  ],
  requiresExplanation: true,
};

export const QUESTION_BANK: Record<string, Question> = {
  rc_v1: RC_V1,
  resistance_v1: RESISTANCE_V1,
  final_v1: FINAL_V1,
};

/** Which question a host may open in each stage. Followup comes from Apply. */
export const STAGE_QUESTION: Partial<Record<Stage, string>> = {
  predict_rc: 'rc_v1',
  resistance: 'resistance_v1',
  final_check: 'final_v1',
};

export const PRE_QUESTION_ID = 'rc_v1';
export const POST_QUESTION_ID = 'final_v1';
