// Additive integration types. The team's frozen contracts.ts remains unchanged.
import type { Stage, TutorDecision } from './contracts';
import type { ExperimentToolCommand } from './experimentTools';
export type TutorProposal = TutorDecision & {proposalId?:string;toolCommand?:ExperimentToolCommand};
export type HostPrivateState = {
  stage: Stage;
  questionId: string|null;
  pendingTutor: TutorProposal|null;
  explanationSamples: string[];
};
export type ToolFeedbackJob = {
  id: string;
  questionId: string;
  stage: Stage;
  answerVersion: number;
  toolVersion: number;
  decision: TutorProposal;
  result: unknown;
};
