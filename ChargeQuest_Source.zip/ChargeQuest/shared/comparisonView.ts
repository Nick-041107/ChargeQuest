import { sampleRC, initialEnergy } from './physics';
import { circuitSVG, experimentDuration } from './experimentView';
import type { ExperimentState } from './experimentView';
import type { ExperimentToolsState } from './experimentTools';
const cf = (x:number, digits=2) => (Math.abs(x)<1e-10 ? 0 : x).toFixed(digits);
const ct = (x:number,y:number,text:string,attributes='') => `<text x="${x}" y="${y}" ${attributes}>${text}</text>`;
const cs = (name:string,index:string) => `${name}<tspan baseline-shift="sub" font-size="9">${index}</tspan>`;
const escapeText = (text:string) => text.replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]!));
const CASE_COLORS = ['#b84139','#2563a6'];
function compareCases(e:ExperimentState, tools:ExperimentToolsState) {
  if (!tools.comparison) throw new Error('Comparison configuration missing');
  return tools.comparison.values.map((R,k)=>({ params:{...e.params,R},R,color:CASE_COLORS[k] }));
}
export function comparisonWaveSVG(e:ExperimentState, tools:ExperimentToolsState, t:number):string {
  const cases=compareCases(e,tools), end=experimentDuration(e);
  const maxI=Math.max(...cases.map(c=>c.params.V0/c.R*1000),1);
  const maxH=Math.max(initialEnergy(e.params)*500,0.001);
  const x=(time:number)=>82+780*time/end;
  const y=(value:number,kind:'i'|'heat')=>(kind==='i'?67:355)+155*(1-value/(kind==='i'?maxI:maxH));
  let grid='';
  for(let k=0;k<5;k++) {
    for(const kind of ['i','heat'] as const) {
      const max=kind==='i'?maxI:maxH, value=max*k/4, top=kind==='i'?67:355,bottom=top+155;
      grid+=`<path d="M82 ${y(value,kind)} H862 M${x(end*k/4)} ${top} V${bottom}" stroke="#e3eaf0"/>`;
      grid+=ct(68,y(value,kind)+4,cf(value,kind==='i'?0:2),'text-anchor="end"');
      grid+=ct(x(end*k/4),bottom+28,cf(end*k/4*1000,2),'text-anchor="middle"');
    }
  }
  const lines=cases.map(c=>{
    const full=Array.from({length:401},(_,k)=>sampleRC(c.params,end*k/400));
    const past=full.filter(s=>s.t<t);past.push(sampleRC(c.params,t));
    return (['i','heat'] as const).map(key=>{
      const path=(list:typeof full)=>list.map((s,k)=>`${k?'L':'M'}${cf(x(s.t))},${cf(y(s[key]*1000,key))}`).join(' ');
      const s=sampleRC(c.params,t), actual=e.status==='idle'&&key==='i'?0:s[key]*1000;
      return `<path d="${path(full)}" fill="none" stroke="${c.color}" opacity="0.13" stroke-dasharray="4 5" stroke-width="2"/>${e.status!=='idle'?`<path d="${path(past)}" fill="none" stroke="${c.color}" stroke-width="3"/>`:''}<circle cx="${x(t)}" cy="${y(actual,key)}" r="4" fill="${c.color}" stroke="white"/>`;
    }).join('');
  }).join('');
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 920 580" data-cq-compare="true" role="img" aria-label="Two resistor experiments with shared physical time axes, current and cumulative heat">
  <g font-family="system-ui,sans-serif"><rect x="1" y="1" width="918" height="276" rx="12" fill="#fbfcfd" stroke="#e3eaf0"/><rect x="1" y="289" width="918" height="283" rx="12" fill="#fbfcfd" stroke="#e3eaf0"/>
  <g font-size="12" fill="#607587">${grid}</g>
  <g font-size="16" fill="#243e50" font-weight="600">${ct(22,31,'Transfer current')}${ct(22,319,'Cumulative heat')}</g>
  <g font-size="11" fill="#6c7f8d">${ct(22,56,'mA')}${ct(22,344,'mJ')}${ct(455,269,'Shared physical time (ms)','text-anchor="middle"')}${ct(455,557,'Shared physical time (ms)','text-anchor="middle"')}</g>
  ${cases.map((c,k)=>ct(555+k*160,31,`— ${cf(c.R,0)} Ω`,`font-size="14" font-weight="600" fill="${c.color}"`)).join('')}
  ${lines}<path d="M${x(t)} 67 V222 M${x(t)} 355 V510" stroke="#7890a0" stroke-dasharray="4 4"/></g><g data-cq-comparison-probe="true" style="display:none;pointer-events:none"></g></svg>`;
}
export function comparisonProbeMarkup(e:ExperimentState,tools:ExperimentToolsState,t:number,svgY=90):string {
  const end=experimentDuration(e), at=Math.max(0,Math.min(end,t)), x=82+780*at/end;
  const cases=compareCases(e,tools), samples=cases.map(c=>sampleRC(c.params,at));
  const bx=Math.max(8,Math.min(554,x>490?x-366:x+16)),by=Math.max(8,Math.min(282,svgY+16));
  const rows:[string,string,string][]=[
    [cs('V','A'),...samples.map(s=>`${cf(s.vA,3)} V`)] as [string,string,string],
    [cs('V','B'),...samples.map(s=>`${cf(s.vB,3)} V`)] as [string,string,string],
    ['Current',...samples.map(s=>`${cf(s.i*1000,2)} mA`)] as [string,string,string],
    [cs('E','A'),...samples.map(s=>`${cf(s.eA*1000,4)} mJ`)] as [string,string,string],
    [cs('E','B'),...samples.map(s=>`${cf(s.eB*1000,4)} mJ`)] as [string,string,string],
    ['Heat',...samples.map(s=>`${cf(s.heat*1000,4)} mJ`)] as [string,string,string],
    ['Total',...samples.map(s=>`${cf((s.eA+s.eB+s.heat)*1000,4)} mJ`)] as [string,string,string],
  ];
  const maxI=Math.max(...cases.map(c=>c.params.V0/c.R*1000),1),maxH=Math.max(initialEnergy(e.params)*500,.001);
  return `<g pointer-events="none" font-family="system-ui,sans-serif"><path d="M${x} 67 V222 M${x} 355 V510" stroke="#243e50" stroke-width="1.5" stroke-dasharray="5 4"/>
  ${samples.map((s,k)=>`<circle cx="${x}" cy="${67+155*(1-s.i*1000/maxI)}" r="5" fill="${CASE_COLORS[k]}" stroke="white"/><circle cx="${x}" cy="${355+155*(1-s.heat*1000/maxH)}" r="5" fill="${CASE_COLORS[k]}" stroke="white"/>`).join('')}
  <rect x="${bx}" y="${by}" width="350" height="270" rx="10" fill="white" stroke="#a9bdca"/>
  ${ct(bx+14,by+24,`t = ${cf(at*1000,4)} ms`,'font-size="15" font-weight="700" fill="#233e52"')}
  ${ct(bx+14,by+42,'MODEL PROBE · shared physical time','font-size="10" fill="#748796"')}
  ${cases.map((c,k)=>ct(bx+222+k*112,by+65,`${cf(c.R,0)} Ω`,`text-anchor="end" font-size="12" font-weight="700" fill="${c.color}"`)).join('')}
  ${rows.map(([label,a,b],k)=>`${(tools.highlight==='voltage'&&k<2)||(tools.highlight==='current'&&k===2)||(tools.highlight==='heat'&&k===5)||(tools.highlight==='energy'&&k>=3&&k<=4)?`<rect x="${bx+7}" y="${by+76+k*24}" width="336" height="22" rx="4" fill="#edf5fc"/>`:''}${ct(bx+14,by+91+k*24,label,'font-size="12" fill="#536e81"')}${ct(bx+222,by+91+k*24,a,'text-anchor="end" font-size="12" fill="#b84139"')}${ct(bx+334,by+91+k*24,b,'text-anchor="end" font-size="12" fill="#2563a6"')}`).join('')}</g>`;
}
export function applyComparisonProbe(root:Element,e:ExperimentState,tools:ExperimentToolsState,clientX:number,clientY:number):void {
  const svg=root.querySelector('[data-cq-compare]'), group=svg?.querySelector('[data-cq-comparison-probe]');
  if(!svg||!group)return;
  const r=svg.getBoundingClientRect();if(r.width<=0||r.height<=0)return;
  const x=(clientX-r.left)/r.width*920,y=(clientY-r.top)/r.height*580;
  if(x<82||x>862||y<60||y>555){group.setAttribute('style','display:none');return;}
  group.innerHTML=comparisonProbeMarkup(e,tools,(x-82)/780*experimentDuration(e),y);
  group.setAttribute('style','display:block;pointer-events:none');
}
export function clearComparisonProbe(root:Element):void {root.querySelector('[data-cq-comparison-probe]')?.setAttribute('style','display:none');}
export function applyPinnedProbe(root:Element,e:ExperimentState,tools:ExperimentToolsState):void {
  if(tools.focusTime===null)return;
  const group=root.querySelector('[data-cq-comparison-probe]');if(!group)return;
  group.innerHTML=comparisonProbeMarkup(e,tools,tools.focusTime,75);group.setAttribute('style','display:block;pointer-events:none');
}
export function comparisonMarkup(e:ExperimentState,tools:ExperimentToolsState,t:number):string {
  const cases=compareCases(e,tools),task=tools.task;
  return `<div class="cq-exp-comparison"><section class="cq-exp-task"><span class="cq-exp-eyebrow">${task?.source==='ai'?'AI-SELECTED EXPERIMENT · APPROVED BY HOST':'MANUAL TOOL DEMO · AI NOT CONNECTED'}</span><h3>Put the prediction to the test.</h3><p><strong>Claim:</strong> ${escapeText(task?.claim??'A smaller resistance produces less heat.')}</p><p><strong>Experiment:</strong> ${escapeText(task?.question??'Change only resistance; hold all other parameters fixed.')}</p>${tools.focusTime!==null?`<div class="cq-exp-focus">Selected probe: ${cf(tools.focusTime*1000,3)} ms · focus: ${escapeText(tools.highlight??'all values')}</div>`:''}</section>
  <div class="cq-exp-comparison-pair">${cases.map((c,k)=>{const s=sampleRC(c.params,t),e0=initialEnergy(c.params);return `<section class="cq-exp-card"><div class="cq-exp-case-heading" style="color:${c.color}">CASE ${k+1} · ${cf(c.R,0)} Ω</div>${circuitSVG({...e,params:c.params},t)}<div class="cq-exp-case-stats"><span>Peak current<br><strong>${cf(c.params.V0/c.R*1000,0)} mA</strong></span><span>Time constant<br><strong>${cf(c.R*c.params.C/2*1000,2)} ms</strong></span><span>Heat now<br><strong>${cf(s.heat*1000,3)} mJ</strong></span></div><div class="cq-exp-footnote">Steady-state heat: ${cf(e0*500,3)} mJ · identical initial energy ${cf(e0*1000,3)} mJ</div></section>`;}).join('')}</div>
  <section class="cq-exp-card cq-exp-waves"><div class="cq-exp-wave-heading"><div class="cq-exp-eyebrow">CONTROLLED COMPARISON · t = ${cf(t*1000,3)} ms</div><span class="cq-exp-wave-help">Same physical time and axes · hover for both cases</span></div><div class="cq-exp-wave-scroll">${comparisonWaveSVG(e,tools,t)}</div></section>
  <section class="cq-exp-card cq-exp-equations"><h3>Different transients. The same final heat.</h3><div class="cq-exp-formula-row"><math xmlns="http://www.w3.org/1998/Math/MathML"><mi>τ</mi><mo>=</mo><mfrac><mrow><mi>R</mi><mi>C</mi></mrow><mn>2</mn></mfrac></math><math xmlns="http://www.w3.org/1998/Math/MathML"><mi>i</mi><mo>(</mo><mi>t</mi><mo>)</mo><mo>=</mo><mfrac><msub><mi>V</mi><mn>0</mn></msub><mi>R</mi></mfrac><msup><mi>e</mi><mrow><mo>−</mo><mi>t</mi><mo>/</mo><mi>τ</mi></mrow></msup></math><math xmlns="http://www.w3.org/1998/Math/MathML"><msub><mi>E</mi><mi>heat</mi></msub><mo>(</mo><mi>∞</mi><mo>)</mo><mo>=</mo><mfrac><mrow><mi>C</mi><msubsup><mi>V</mi><mn>0</mn><mn>2</mn></msubsup></mrow><mn>4</mn></mfrac></math></div><p class="cq-exp-footnote">These equations apply to two equal capacitors initially at V<sub>0</sub> and 0 V, connected through a nonzero resistance.</p></section></div>`;
}
