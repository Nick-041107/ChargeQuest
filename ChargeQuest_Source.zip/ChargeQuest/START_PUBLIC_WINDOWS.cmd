@echo off
cd /d "%~dp0"
node SHARE.cjs
if errorlevel 1 pause
