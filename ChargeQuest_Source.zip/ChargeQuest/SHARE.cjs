'use strict';
const fs=require('node:fs');process.chdir(__dirname);
try{const state=JSON.parse(fs.readFileSync('.active-port.json','utf8'));process.env.PORT=String(state.port);}catch{console.error('Start the classroom with node START.cjs first.');process.exit(1);}
require('./scripts/public-share.cjs');
