@echo off
cd /d "%~dp0"
node START.cjs
if errorlevel 1 pause
