'use strict';
const fs=require('node:fs'),path=require('node:path'),net=require('node:net'),{spawn,spawnSync}=require('node:child_process');
const root=__dirname;process.chdir(root);let server,ownedOllama;
function run(exe,args){return new Promise((resolve,reject)=>{const c=spawn(exe,args,{cwd:root,stdio:'inherit',windowsHide:false});c.once('error',reject);c.once('exit',code=>code===0?resolve():reject(Error(`${exe} exited with code ${code}`)));});}
async function localReady(){try{return (await fetch('http://127.0.0.1:11434/api/tags',{signal:AbortSignal.timeout(2000)})).ok;}catch{return false;}}
function findOllama(){const probe=spawnSync('ollama',['--version'],{stdio:'ignore',windowsHide:true});if(!probe.error)return 'ollama';const p=path.join(process.env.LOCALAPPDATA||'','Programs','Ollama','ollama.exe');return fs.existsSync(p)?p:null;}
function free(port){return new Promise(resolve=>{const s=net.createServer();s.once('error',()=>resolve(false));s.listen(port,'0.0.0.0',()=>s.close(()=>resolve(true)));});}
function open(url){if(process.platform==='win32')spawn('explorer.exe',[url],{stdio:'ignore',windowsHide:true}).on('error',()=>{});}
async function main(){
 console.log('\nCHARGEQUEST — LOCAL MODEL SUBMISSION EDITION\n');
 const [major,minor]=process.versions.node.split('.').map(Number);if(major<22||(major===22&&minor<12))throw Error('Use your installed Node.js 22.12 or newer.');
 if(!fs.existsSync('dist/server/research.cjs'))throw Error('Extract the complete zip, then run START.cjs from that folder.');
 const ollama=findOllama();
 if(!ollama){console.log('First use: install Ollama from https://ollama.com/download/windows');console.log('After installation, reopen PowerShell and run: node START.cjs');open('https://ollama.com/download/windows');return;}
 if(!(await localReady())){console.log('Starting the local model service…');ownedOllama=spawn(ollama,['serve'],{stdio:'ignore',windowsHide:true});ownedOllama.on('error',()=>{});for(let k=0;k<30;k++){if(await localReady())break;await new Promise(r=>setTimeout(r,400));}if(!(await localReady()))throw Error('Open Ollama from the Start menu, then run START.cjs again.');}
 const model='qwen2.5:3b',tags=await(await fetch('http://127.0.0.1:11434/api/tags')).json();
 if(!tags.models?.some(m=>m.name===model||m.model===model)){console.log('First use: downloading the 1.9 GB local model. Download speed depends on your connection.');await run(ollama,['pull',model]);}
 console.log('Loading model into memory. First load may take a while…');
 const ready=await fetch('http://127.0.0.1:11434/api/chat',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({model,messages:[{role:'user',content:'Reply only OK.'}],stream:false,keep_alive:'20m',options:{num_predict:12,num_ctx:4096}}),signal:AbortSignal.timeout(180000)});if(!ready.ok)throw Error('Model warmup failed. Check Ollama and retry.');const warm=await ready.json();if(!warm.message?.content)throw Error('Model did not complete warmup.');
 console.log('Local model ready. No cloud model key is used.');
 let port=0;for(let p=3001;p<=3010;p++)if(await free(p)){port=p;break;}if(!port)throw Error('Ports 3001–3010 are busy. Close an old classroom and retry.');
 fs.writeFileSync('.active-port.json',JSON.stringify({port,pid:process.pid}));
 server=spawn(process.execPath,['dist/server/index.js'],{cwd:root,env:{...process.env,PORT:String(port),AI_API_KEY:'ollama',AI_BASE_URL:'http://127.0.0.1:11434/v1',AI_MODEL:model,AGENT_LOCAL_ROUNDS:'1'},stdio:'inherit',windowsHide:true});
 server.once('error',e=>console.error(e.message));server.once('exit',code=>{console.log('Classroom stopped.');process.exitCode=code||0;cleanup();});
 for(let k=0;k<30;k++){try{const r=await fetch(`http://127.0.0.1:${port}/api/health`,{signal:AbortSignal.timeout(1000)});if(r.ok){console.log(`\nREADY: http://localhost:${port}\nKeep this window open.\nExternal phones: open a second PowerShell here and run node SHARE.cjs\n`);open(`http://localhost:${port}`);return;}}catch{}await new Promise(r=>setTimeout(r,300));}
 throw Error('The classroom did not become ready. See the server message above.');
}
function cleanup(){if(server)server.kill();if(ownedOllama)ownedOllama.kill();try{const p=JSON.parse(fs.readFileSync('.active-port.json'));if(p.pid===process.pid)fs.unlinkSync('.active-port.json');}catch{}}
process.on('SIGINT',()=>{cleanup();process.exit(0);});process.on('SIGTERM',()=>{cleanup();process.exit(0);});
if(require.main===module)main().catch(e=>{console.error('\n'+e.message);cleanup();process.exitCode=1;});
module.exports={findOllama,free};
