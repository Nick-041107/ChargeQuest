import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import vm from 'node:vm';
import { DEFAULT_PARAMS } from '../shared/physics.ts';
import { timeAt, experimentDuration, circuitSVG, experimentMarkup, probeTimeAt, probeMarkup, applyWaveProbe } from '../shared/experimentView.ts';
import type { ExperimentState } from '../shared/experimentView.ts';
const base: ExperimentState = {mode:'rc',status:'idle',params:{...DEFAULT_PARAMS},simTime:0,updatedAt:1000,playbackRate:0.01,stopAtFirstZero:true,runId:0};
test('Timeline interpolates with milliseconds offset, clamps and respects pause', () => {
  assert.equal(timeAt({...base,status:'running'},1500),0.005);
  assert.equal(timeAt({...base,status:'running'},1400,100),0.005);
  assert.equal(timeAt({...base,status:'paused',simTime:0.004},999999),0.004);
  assert.equal(timeAt({...base,status:'running'},999999),experimentDuration(base));
});
test('LC first-zero stopping and full cycle are distinct', () => {
  const e={...base,mode:'lc' as const};
  assert.equal(experimentDuration({...e,stopAtFirstZero:false}),2*experimentDuration(e));
  assert.match(circuitSVG({...e,status:'finished'},experimentDuration(e)),/OPEN · energy held in B/);
  assert.doesNotMatch(circuitSVG({...e,status:'finished',stopAtFirstZero:false},experimentDuration({...e,stopAtFirstZero:false})),/OPEN · energy held in B/);
});
test('Initial open switch shows no actual current; RC limit is labelled', () => {
  assert.match(circuitSVG(base,0),/i = 0.0 mA/);
  const html=experimentMarkup(base,0);
  assert.match(html,/Steady-state limit/); assert.match(html,/Delivered to B: 25%/);
});
test('Generated preview JavaScript parses without browser dependencies', () => {
  const html=readFileSync(new URL('../docs/source/C_PREVIEW.html',import.meta.url),'utf8');
  const script=html.match(/<script>([\s\S]*?)<\/script>/)![1];
  assert.doesNotThrow(()=>new vm.Script(script));
});
test('Hover maps exact plot edges and midpoint to simulation time', () => {
  assert.equal(probeTimeAt(base,82),0);
  assert.equal(probeTimeAt(base,862),experimentDuration(base));
  assert.equal(probeTimeAt(base,472),experimentDuration(base)/2);
  assert.equal(probeTimeAt(base,-100),0);
});
test('Probe includes physical voltage, current, energies and heat without changing state', () => {
  const before=JSON.stringify(base);
  const html=probeMarkup(base,0.005);
  assert.match(html,/6.839 V/);assert.match(html,/36.788 mA/);
  assert.match(html,/Cumulative heat/);assert.match(html,/5.0000 mJ/);
  assert.equal(JSON.stringify(base),before);
});
test('Probe scales client coordinates and hides outside plotting area', () => {
  const group={innerHTML:'',style:'',setAttribute(_key:string,value:string){this.style=value;}};
  const svg={querySelector(){return group;},getBoundingClientRect(){return {left:100,top:50,width:460,height:290};}};
  const root={querySelector(selector:string){return selector==='[data-cq-wave]'?svg:group;}};
  applyWaveProbe(root as unknown as Element,base,336,100);
  assert.match(group.style,/display:block/);assert.match(group.innerHTML,/25.0000 ms/);
  applyWaveProbe(root as unknown as Element,base,0,0);
  assert.match(group.style,/display:none/);
});
