import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import vm from 'node:vm';
import { executeExperimentTool, validateToolCommand, emptyTools, makeDemoExperiment } from '../shared/experimentTools.ts';
import { comparisonMarkup } from '../shared/comparisonView.ts';
import { circuitSVG, waveSVG } from '../shared/experimentView.ts';
const state=makeDemoExperiment(1000);
const compare=()=>executeExperimentTool(state,emptyTools(),{action:'compare_resistance',values:[100,10]},{now:1000,source:'manual'});
test('Comparison uses one physical clock and truthful independent results',()=>{
  const o=compare();assert.equal(o.experiment.params.R,100);assert.equal(o.experiment.mode,'rc');
  assert.equal(o.experiment.playbackRate,0.05/8);
  assert.ok('cases' in o.result);
  const result=o.result as {cases:{peakCurrent:number;final:{heat:number}}[]};
  assert.equal(result.cases[0].peakCurrent,0.1);assert.equal(result.cases[1].peakCurrent,1);
  assert.equal(result.cases[0].final.heat,0.0025);assert.equal(result.cases[1].final.heat,0.0025);
});
test('Inspect is non-mutating and returns both cases at same selected time',()=>{
  const o=compare(),before=JSON.stringify(o);
  const r=executeExperimentTool(o.experiment,o.tools,{action:'inspect_time',timeMs:.5,highlight:'current'},{now:2000,source:'manual'});
  assert.equal(r.experiment,o.experiment);assert.equal(r.tools.focusTime,.0005);
  assert.equal(JSON.stringify(o),before);assert.ok('samples' in r.result);
  const samples=(r.result as {samples:{t:number;i:number}[]}).samples;
  assert.equal(samples.length,2);assert.equal(samples[0].t,samples[1].t);assert.ok(samples[1].i>samples[0].i);
});
test('Tool input rejects invalid values, unknown actions and out-of-range probes',()=>{
  for(const values of [[0,10],[10,Infinity],[10,10],[10,20,30]])assert.throws(()=>validateToolCommand({action:'compare_resistance',values}));
  assert.throws(()=>validateToolCommand({action:'run_code',code:'...'}));
  assert.throws(()=>executeExperimentTool(state,emptyTools(),{action:'inspect_time',timeMs:100,highlight:'heat'},{now:1000,source:'manual'}));
});
test('UI escapes task text and renders real subscripts and mathematical fractions',()=>{
  const o=compare();o.tools.task!.claim='<img src=x onerror=alert(1)>';
  const html=comparisonMarkup(o.experiment,o.tools,0.001);
  assert.ok(html.includes('&lt;img'));assert.ok(!html.includes('<img'));
  assert.match(html,/<mfrac>/);assert.match(html,/<msub>/);
  for(const svg of [circuitSVG(state,0),waveSVG(state,0)]){assert.doesNotMatch(svg,/V_A|V_B/);assert.match(svg,/baseline-shift="sub"/);}
});
test('Generated preview executes its manual comparison and pin controls in a minimal DOM harness',()=>{
  const nodes=new Map<string,Record<string,any>>();
  const node=(id:string)=>{if(!nodes.has(id))nodes.set(id,{value:'',style:{},classList:{toggle(){}},dataset:{},addEventListener(){},querySelector(){return null;}});return nodes.get(id)!;};
  const tabs=['rc','lc'].map(mode=>({...node(mode),dataset:{mode}}));
  const document={getElementById:node,querySelectorAll(){return tabs;}};
  const html=readFileSync(new URL('../docs/source/C_PREVIEW.html',import.meta.url),'utf8');
  const script=html.match(/<script>([\s\S]*?)<\/script>/)![1];
  const context=vm.createContext({document,Date,console,requestAnimationFrame(){return 1;}});
  vm.runInContext(script,context);
  node('compare').onclick();assert.match(node('experiment').innerHTML,/CONTROLLED COMPARISON/);assert.match(node('experiment').innerHTML,/MANUAL TOOL DEMO/);
  node('pin').onclick();assert.equal(vm.runInContext('tools.focusTime',context),0.0005);
  node('unpin').onclick();assert.equal(vm.runInContext('tools.focusTime',context),null);
  tabs[1].onclick();assert.equal(vm.runInContext('e.mode',context),'lc');assert.equal(vm.runInContext('tools.comparison',context),null);
});
