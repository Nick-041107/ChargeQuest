import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readPublicOrigin } from '../client/src/lib/shareLink';
test('only unexpired HTTPS origins are accepted as public QR destinations',()=>{
  const valid={origin:'https://classroom.trycloudflare.com',expiresAt:2000};
  assert.equal(readPublicOrigin(valid,1000),valid.origin);
  for(const data of [null,{}, {...valid,expiresAt:500},{...valid,expiresAt:NaN},{...valid,origin:'http://localhost:3001'},{...valid,origin:'https://localhost'},{...valid,origin:'https://name:secret@example.com'},{...valid,origin:'https://example.com/a'},{...valid,origin:'https://example.com?token=x'}])assert.equal(readPublicOrigin(data,1000),null);
});
