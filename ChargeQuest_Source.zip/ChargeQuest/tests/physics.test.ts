import test from 'node:test';
import assert from 'node:assert/strict';
import { DEFAULT_PARAMS, sampleRC, sampleLC, steadyStateRC, getTiming, initialEnergy, energyBalance } from '../shared/physics.ts';

const p = { ...DEFAULT_PARAMS };
const near = (actual: number, expected: number, tolerance = 1e-10) => {
  assert.ok(Math.abs(actual - expected) <= tolerance * Math.max(1, Math.abs(expected)), `${actual} != ${expected}`);
};
test('Initial RC values: 10 V, 0 V, 100 mA and 5 mJ', () => {
  const s = sampleRC(p, 0);
  near(s.vA, 10); near(s.vB, 0); near(s.i, 0.1); near(s.eA, 0.005); near(s.heat, 0);
});
test('RC steady state: 5 V each, 1.25 mJ each, 2.5 mJ heat', () => {
  const s = steadyStateRC(p);
  near(s.vA, 5); near(s.vB, 5); near(s.eA, 0.00125); near(s.eB, 0.00125); near(s.heat, 0.0025);
});
test('Lower R changes transient speed, not final heat', () => {
  const small = { ...p, R: 10 };
  assert.ok(sampleRC(small, 0.001).vB > sampleRC(p, 0.001).vB);
  assert.ok(sampleRC(small, 0).i > sampleRC(p, 0).i);
  near(steadyStateRC(small).heat, steadyStateRC(p).heat);
});
test('RC and LC conserve total charge and accounted energy throughout', () => {
  for (const R of [10, 100, 1000]) for (const V0 of [0, 8, 10]) {
    const params = { ...p, R, V0 };
    for (const mode of ['rc', 'lc'] as const) {
      const duration = getTiming(mode, params).duration;
      for (let k = 0; k <= 1000; k++) {
        const s = (mode === 'rc' ? sampleRC : sampleLC)(params, duration * k / 1000);
        assert.ok(energyBalance(params, s).relativeError < 1e-9);
        near(params.C * (s.vA + s.vB), params.C * V0);
      }
    }
  }
});
test('Heat accumulation equals integral of i²R', () => {
  const duration = getTiming('rc', p).duration;
  const n = 20000, dt = duration / n;
  let heat = 0;
  for (let k = 0; k < n; k++) { const s = sampleRC(p, (k + 0.5) * dt); heat += s.i ** 2 * p.R * dt; }
  assert.ok(Math.abs(heat - sampleRC(p, duration).heat) < 1e-9);
});
test('Mid-transfer LC: both at 5 V, half energy in L', () => {
  const s = sampleLC(p, getTiming('lc', p).firstZero! / 2);
  near(s.vA, 5); near(s.vB, 5); near(s.eL, initialEnergy(p) / 2);
});
test('First zero transfers all initial energy to B; full period returns it', () => {
  const t = getTiming('lc', p).firstZero!;
  const s = sampleLC(p, t), returned = sampleLC(p, 2 * t);
  near(s.vA, 0); near(s.vB, 10); near(s.i, 0); near(s.eB, initialEnergy(p));
  near(returned.vA, 10); near(returned.vB, 0); near(returned.i, 0);
});
test('Finite-time RC is not silently snapped to its limit', () => {
  const s = sampleRC(p, getTiming('rc', p).duration);
  assert.ok(s.vA > 5); assert.ok(s.vB < 5); assert.ok(s.i > 0);
});
test('Invalid parameters/time fail clearly', () => {
  for (const C of [0, -1, NaN, Infinity]) assert.throws(() => sampleRC({ ...p, C }, 0), RangeError);
  for (const R of [0, -1]) assert.throws(() => sampleRC({ ...p, R }, 0), RangeError);
  assert.throws(() => sampleLC({ ...p, L: 0 }, 0), RangeError);
  assert.throws(() => sampleRC(p, -1), RangeError);
});
