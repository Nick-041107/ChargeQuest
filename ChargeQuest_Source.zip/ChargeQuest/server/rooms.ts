/**
 * ChargeQuest - in-memory rooms, the single source of truth. Owner: B.
 * Handoff v2 sections 5, 9, 13.
 *
 * One Node process, rooms kept in memory. A restart clears everything.
 * Every mutation bumps `revision`; clients ignore older snapshots.
 * Raw answers NEVER enter the public snapshot.
 */

import { randomBytes, randomInt } from 'node:crypto';
import {
  DEFAULT_PARAMS,
  FINAL_CHECK_PARAMS,
  MAX_EXPLANATION,
  MAX_STUDENTS,
  NICKNAME_MAX,
  NICKNAME_MIN,
  R_MAX,
  R_MIN,
  type Ack,
  type Aggregate,
  type ClientSession,
  type ExperimentPanelProps,
  type ExperimentState,
  type PhysicsParams,
  type PrivateSession,
  type Question,
  type RoomSnapshot,
  type SessionResults,
  type Stage,
  type StudentSubmitPayload,
  type Submission,
  type TutorDecision,
  type TutorInput,
} from '../shared/contracts';
import {
  QUESTION_BANK,
  POST_QUESTION_ID,
  PRE_QUESTION_ID,
  STAGE_QUESTION,
} from '../shared/questions';
import { isCorrect, PAIR_POST, PAIR_PRE } from './questionsAnswerKey';
import { getTiming, physicsFacts } from './physics';
import { emptyTools, executeExperimentTool, type ExperimentToolsState, validateToolCommand } from '../shared/experimentTools';
import type { TutorProposal, HostPrivateState, ToolFeedbackJob } from '../shared/extensions';
import { toolResultMessage } from './toolFeedback';

const ROOM_IDLE_TTL_MS = 2 * 60 * 60 * 1000;
const SUBMIT_WINDOW_MS = 2000;
const SUBMIT_WINDOW_MAX = 5;
const TUTOR_COOLDOWN_MS = 1500;
const MAX_FOLLOWUP_ROUNDS = 2;

type Participant = {
  id: string;
  nickname: string;
  token: string;
  connected: boolean;
};

type Room = {
  code: string;
  hostToken: string;
  revision: number;
  stage: Stage;
  participants: Map<string, Participant>;
  question: Question | null;
  questionOpen: boolean;
  closedQuestionIds: Set<string>;
  /** Frozen at open time. Late joiners spectate this question; disconnected
   *  participants stay eligible. */
  eligibleByQuestion: Map<string, Set<string>>;
  /** questionId -> participantId -> Submission (overwrite, never accumulate) */
  submissions: Map<string, Map<string, Submission>>;
  aggregate: Aggregate | null;
  experiment: ExperimentState;
  experimentTools: ExperimentToolsState;
  toolRequests: Map<string, unknown>;
  tutor: TutorDecision | null;
  /** Latest valid decision awaiting host Apply. Never client-supplied. */
  pendingTutor: TutorProposal | null;
  appliedProposals: Set<string>;
  toolVersion: number;
  feedbackJob: ToolFeedbackJob|null;
  feedbackToken: string|null;
  tutorBinding: { questionId: string; stage: Stage; answerVersion: number } | null;
  tutorInFlight: boolean;
  previousDecisions: TutorDecision[];
  answerVersion: number;
  /** Answer submissions or question-close bump this (NOT snapshot revision). */
  tutorLastRequestAt: number;
  followupCount: number;
  submitWindow: Map<string, number[]>;
  createdAt: number;
  lastActivityAt: number;
};

export class RoomStore {
  private rooms = new Map<string, Room>();

  private newToken(): string {
    return randomBytes(24).toString('base64url');
  }

  private newParticipantId(): string {
    return randomBytes(12).toString('base64url');
  }

  private makeCode(): string {
    for (let i = 0; i < 50; i += 1) {
      const code = String(randomInt(0, 1_000_000)).padStart(6, '0');
      if (!this.rooms.has(code)) return code;
    }
    throw new Error('Unable to allocate a unique room code');
  }

  private freshExperiment(stage: Stage): ExperimentState {
    const params = stage === 'final_check'
      ? { ...FINAL_CHECK_PARAMS }
      : { ...DEFAULT_PARAMS };
    return {
      mode: stage === 'lc' ? 'lc' : 'rc',
      status: 'idle',
      params,
      simTime: 0,
      updatedAt: Date.now(),
      playbackRate: this.playbackRate(stage === 'lc' ? 'lc' : 'rc', params, false),
      stopAtFirstZero: false,
      runId: 1,
    };
  }

  private duration(exp: ExperimentState): number {
    const { duration, firstZero } = getTiming(exp.mode, exp.params);
    if (exp.mode === 'lc' && exp.stopAtFirstZero && firstZero !== null) {
      return firstZero;
    }
    return duration;
  }

  /** Simulation seconds per real second, so a run takes about 6 seconds. */
  private playbackRate(
    mode: 'rc' | 'lc',
    params: PhysicsParams,
    stopAtFirstZero: boolean
  ): number {
    const { duration, firstZero } = getTiming(mode, params);
    const target = mode === 'lc' && stopAtFirstZero && firstZero !== null
      ? firstZero
      : duration;
    return target / 6;
  }

  createRoom(): Ack<{ code: string; hostToken: string }> {
    const code = this.makeCode();
    const hostToken = this.newToken();
    const now = Date.now();
    const room: Room = {
      code,
      hostToken,
      revision: 1,
      stage: 'lobby',
      participants: new Map(),
      question: null,
      questionOpen: false,
      closedQuestionIds: new Set(),
      eligibleByQuestion: new Map(),
      submissions: new Map(),
      aggregate: null,
      experiment: this.freshExperiment('lobby'),
      experimentTools: emptyTools(),
      toolRequests: new Map(),
      tutor: null,
      pendingTutor: null,
      appliedProposals: new Set(),
      toolVersion: 0,
      feedbackJob: null,
      feedbackToken: null,
      tutorBinding: null,
      tutorInFlight: false,
      previousDecisions: [],
      answerVersion: 0,
      tutorLastRequestAt: 0,
      followupCount: 0,
      submitWindow: new Map(),
      createdAt: now,
      lastActivityAt: now,
    };
    this.rooms.set(code, room);
    return { ok: true, data: { code, hostToken } };
  }

  join(code: string, nickname: string): Ack<{ participantId: string; studentToken: string }> {
    const room = this.rooms.get(code);
    if (!room) return { ok: false, error: 'Room not found' };
    const name = nickname.trim();
    if (name.length < NICKNAME_MIN || name.length > NICKNAME_MAX) {
      return { ok: false, error: 'Nickname must be 1-24 characters' };
    }
    const students = [...room.participants.values()].length;
    if (students >= MAX_STUDENTS) {
      return { ok: false, error: 'Room is full (max 30 students)' };
    }
    const participantId = this.newParticipantId();
    const studentToken = this.newToken();
    room.participants.set(participantId, {
      id: participantId,
      nickname: name,
      token: studentToken,
      connected: false,
    });
    this.touch(room);
    return { ok: true, data: { participantId, studentToken } };
  }

  /** Resolve a handshake auth into a verified session. */
  resolve(auth: { roomCode: string; token: string }): ClientSession | null {
    const room = this.rooms.get(auth.roomCode);
    if (!room) return null;
    if (auth.token === room.hostToken) {
      return { role: 'host', token: auth.token, participantId: null, roomCode: room.code };
    }
    for (const p of room.participants.values()) {
      if (p.token === auth.token) {
        return {
          role: 'student',
          token: auth.token,
          participantId: p.id,
          roomCode: room.code,
        };
      }
    }
    return null;
  }

  setConnected(code: string, participantId: string, connected: boolean): void {
    const room = this.rooms.get(code);
    const p = room?.participants.get(participantId);
    if (!room || !p) return;
    p.connected = connected;
    this.touch(room);
  }

  private touch(room: Room): void {
    room.lastActivityAt = Date.now();
    room.revision += 1;
  }

  get(code: string): Room | undefined {
    return this.rooms.get(code);
  }

  /** Public snapshot: no raw answers, no explanations, no tokens. */
  snapshot(code: string): (RoomSnapshot & {experimentTools: ExperimentToolsState}) | null {
    const room = this.rooms.get(code);
    if (!room) return null;
    // Settle the simulation clock against the server's own time.
    this.settleExperiment(room);
    const currentSubmissions = room.question
      ? room.submissions.get(room.question.id)?.size ?? 0
      : 0;
    return {
      code: room.code,
      revision: room.revision,
      serverNow: Date.now(),
      stage: room.stage,
      participants: [...room.participants.values()].map((p) => ({
        id: p.id,
        nickname: p.nickname,
        connected: p.connected,
      })),
      question: room.question,
      questionOpen: room.questionOpen,
      aggregate: room.questionOpen ? null : room.aggregate,
      submittedCount: currentSubmissions,
      experiment: { ...room.experiment, params: { ...room.experiment.params } },
      experimentTools: room.experimentTools,
      tutor: room.tutor,
    };
  }

  /** Private channel: only ever emitted to that one participant's socket. */
  privateSession(code: string, participantId: string | null): PrivateSession {
    const room = this.rooms.get(code);
    if (!room || !participantId) return { mySubmissions: [], eligibleQuestionIds: [] };
    const mine: Submission[] = [];
    for (const [questionId, byParticipant] of room.submissions) {
      const s = byParticipant.get(participantId);
      if (s) mine.push(s);
    }
    const eligibleQuestionIds = [...room.eligibleByQuestion.entries()]
      .filter(([, ids]) => ids.has(participantId))
      .map(([questionId]) => questionId);
    return { mySubmissions: mine, eligibleQuestionIds };
  }

  hostPrivate(code:string):HostPrivateState|null {
    const room=this.rooms.get(code);if(!room)return null;
    const redact=(raw:string)=>{
      let text=raw;
      for(const p of room.participants.values()){
        const escaped=p.nickname.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
        text=text.replace(new RegExp(`(?<![\\p{L}\\p{N}])${escaped}(?![\\p{L}\\p{N}])`,'giu'),'[name]');
        text=text.split(p.token).join('[redacted]').split(p.id).join('[redacted]');
      }
      return text.split(room.hostToken).join('[redacted]').slice(0,280);
    };
    const samples=room.question&&!room.questionOpen?[...(room.submissions.get(room.question.id)?.values()??[])].map(s=>redact(s.explanation)).filter(Boolean).slice(0,3):[];
    return {stage:room.stage,questionId:room.question?.id??null,pendingTutor:room.pendingTutor,explanationSamples:samples};
  }

  /** Class-wide paired metric + this participant's own answers. */
  results(code: string, participantId: string | null): SessionResults {
    const room = this.rooms.get(code);
    const empty: SessionResults = {
      mySubmissions: [],
      pairedCount: 0,
      preCorrect: 0,
      postCorrect: 0,
    };
    if (!room) return empty;
    const mine: Submission[] = [];
    for (const byParticipant of room.submissions.values()) {
      const s = participantId ? byParticipant.get(participantId) : undefined;
      if (s) mine.push(s);
    }
    const pre = room.submissions.get(PAIR_PRE) ?? new Map<string, Submission>();
    const post = room.submissions.get(PAIR_POST) ?? new Map<string, Submission>();
    let pairedCount = 0;
    let preCorrect = 0;
    let postCorrect = 0;
    for (const [pid, preSub] of pre) {
      const postSub = post.get(pid);
      if (!postSub) continue;
      pairedCount += 1;
      if (isCorrect(PAIR_PRE, preSub.optionId)) preCorrect += 1;
      if (isCorrect(PAIR_POST, postSub.optionId)) postCorrect += 1;
    }
    return { mySubmissions: mine, pairedCount, preCorrect, postCorrect };
  }

  /* ---------------------------- experiment clock --------------------------- */

  private settleExperiment(room: Room): void {
    const exp = room.experiment;
    const now = Date.now();
    if (exp.status === 'running') {
      const elapsedRealSec = Math.max(0, (now - exp.updatedAt) / 1000);
      const next = Math.min(
        exp.simTime + elapsedRealSec * exp.playbackRate,
        this.duration(exp)
      );
      exp.simTime = next;
      if (next >= this.duration(exp) - 1e-12) exp.status = 'finished';
    }
    exp.updatedAt = now;
  }

  /* ------------------------------- host actions ---------------------------- */

  setStage(code: string, stage: Stage): Ack {
    const room = this.rooms.get(code);
    if (!room) return { ok: false, error: 'Room not found' };
    const allowed: Stage[] = [
      'lobby', 'predict_rc', 'reveal_rc', 'resistance', 'lc', 'final_check', 'results',
    ];
    if (!allowed.includes(stage)) return { ok: false, error: 'Invalid stage' };
    // Changing stage closes the old question, clears tutor, resets experiment,
    // but KEEPS all per-question history.
    if (room.questionOpen) this.closeCurrentQuestion(room);
    const preserveRC=stage==='reveal_rc'&&room.question?.kind==='rc_energy';
    if(!preserveRC)room.question = null;
    room.questionOpen = false;
    if(!preserveRC)room.aggregate = null;
    room.tutor = null;
    room.pendingTutor = null;
    room.tutorBinding = null;
    room.stage = stage;
    const nextRunId = room.experiment.runId + 1;
    room.experiment = {...this.freshExperiment(stage),runId:nextRunId};
    room.experimentTools = emptyTools();
    room.toolVersion += 1;
    this.touch(room);
    return { ok: true, data: undefined };
  }

  openQuestion(code: string, questionId: string): Ack {
    const room = this.rooms.get(code);
    if (!room) return { ok: false, error: 'Room not found' };
    if (room.questionOpen) return { ok: false, error: 'A question is already open' };
    if (room.closedQuestionIds.has(questionId)) {
      return { ok: false, error: 'Closed questions cannot be reopened' };
    }
    const expected = STAGE_QUESTION[room.stage];
    if (!expected || expected !== questionId) {
      return { ok: false, error: 'Question does not match the current stage' };
    }
    const question = QUESTION_BANK[questionId];
    if (!question) return { ok: false, error: 'Unknown question' };

    // Freeze eligibility at open time: only students present now may answer.
    const eligible = new Set([...room.participants.values()].filter(p=>p.connected).map(p=>p.id));
    room.eligibleByQuestion.set(questionId, eligible);
    room.submissions.set(questionId, new Map());
    room.question = question;
    room.questionOpen = true;
    room.experimentTools = emptyTools();
    room.toolVersion += 1;
    room.aggregate = null;
    this.bumpAnswerVersion(room);
    this.touch(room);
    return { ok: true, data: undefined };
  }

  private closeCurrentQuestion(room: Room): void {
    const q = room.question;
    if (!q) return;
    room.questionOpen = false;
    room.closedQuestionIds.add(q.id);
    const eligible = room.eligibleByQuestion.get(q.id) ?? new Set<string>();
    const byParticipant = room.submissions.get(q.id) ?? new Map<string, Submission>();
    const counts: Record<string, number> = {};
    for (const s of byParticipant.values()) {
      const key = s.optionId ?? 'null';
      counts[key] = (counts[key] ?? 0) + 1;
    }
    room.aggregate = {
      submitted: byParticipant.size,
      eligible: eligible.size,
      counts,
    };
    this.bumpAnswerVersion(room);
  }

  closeQuestion(code: string): Ack {
    const room = this.rooms.get(code);
    if (!room) return { ok: false, error: 'Room not found' };
    if (!room.questionOpen) return { ok: false, error: 'No open question' };
    this.closeCurrentQuestion(room);
    this.touch(room);
    return { ok: true, data: undefined };
  }

  submit(code: string, participantId: string | null, payload: StudentSubmitPayload): Ack {
    const room = this.rooms.get(code);
    if (!room) return { ok: false, error: 'Room not found' };
    if (!participantId) return { ok: false, error: 'Only students may submit' };
    if (!room.questionOpen || !room.question) {
      return { ok: false, error: 'No question is open' };
    }
    if (payload.questionId !== room.question.id) {
      return { ok: false, error: 'Question mismatch' };
    }
    const eligible = room.eligibleByQuestion.get(room.question.id);
    if (!eligible || !eligible.has(participantId)) {
      return { ok: false, error: 'You joined after this question opened' };
    }
    const q = room.question;
    if (q.options.length > 0) {
      if (!payload.optionId || !q.options.some((o) => o.id === payload.optionId)) {
        return { ok: false, error: 'Invalid option' };
      }
    } else if (payload.optionId !== null) {
      return { ok: false, error: 'Followup expects free text, not an option' };
    }
    const explanation = (payload.explanation ?? '').trim();
    if (explanation.length > MAX_EXPLANATION) {
      return { ok: false, error: 'Explanation too long' };
    }
    if (q.requiresExplanation && explanation.length === 0) {
      return { ok: false, error: 'Explanation is required' };
    }
    const confidence = Number(payload.confidence);
    if (!Number.isFinite(confidence) || confidence < 0 || confidence > 100) {
      return { ok: false, error: 'Confidence must be 0-100' };
    }
    // Simple per-participant rate limit.
    const now = Date.now();
    const recent = (room.submitWindow.get(participantId) ?? []).filter(
      (t) => now - t < SUBMIT_WINDOW_MS
    );
    if (recent.length >= SUBMIT_WINDOW_MAX) {
      return { ok: false, error: 'Too many submissions, please wait' };
    }
    recent.push(now);
    room.submitWindow.set(participantId, recent);

    // Overwrite by participantId: repeated clicks never increase the count.
    const byParticipant = room.submissions.get(q.id) ?? new Map<string, Submission>();
    byParticipant.set(participantId, {
      participantId,
      questionId: q.id,
      optionId: payload.optionId,
      explanation,
      confidence,
      submittedAt: now,
    });
    room.submissions.set(q.id, byParticipant);
    this.bumpAnswerVersion(room);
    this.touch(room);
    return { ok: true, data: undefined };
  }

  private bumpAnswerVersion(room: Room): void {
    room.answerVersion += 1;
  }

  setExperiment(
    code: string,
    payload: { mode: 'rc' | 'lc'; params: PhysicsParams; stopAtFirstZero: boolean }
  ): Ack {
    const room = this.rooms.get(code);
    if (!room) return { ok: false, error: 'Room not found' };
    if (payload.mode !== 'rc' && payload.mode !== 'lc') {
      return { ok: false, error: 'Invalid mode' };
    }
    const p = payload.params;
    if (!p || !Number.isFinite(p.R) || p.R < R_MIN || p.R > R_MAX) {
      return { ok: false, error: `R must be between ${R_MIN} and ${R_MAX} ohm` };
    }
    // C and L are fixed; V0 is fixed per stage. Never accept arbitrary values.
    const base = room.stage === 'final_check' ? FINAL_CHECK_PARAMS : DEFAULT_PARAMS;
    const params: PhysicsParams = { C: base.C, V0: base.V0, R: p.R, L: base.L };
    const stopAtFirstZero = payload.mode === 'lc' && Boolean(payload.stopAtFirstZero);
    room.experimentTools = emptyTools();
    room.toolVersion += 1;
    room.experiment = {
      mode: payload.mode,
      status: 'idle',
      params,
      simTime: 0,
      updatedAt: Date.now(),
      playbackRate: this.playbackRate(payload.mode, params, stopAtFirstZero),
      stopAtFirstZero,
      runId: room.experiment.runId + 1,
    };
    this.touch(room);
    return { ok: true, data: undefined };
  }

  experimentControl(code: string, command: 'play' | 'pause' | 'reset'): Ack {
    const room = this.rooms.get(code);
    if (!room) return { ok: false, error: 'Room not found' };
    if (!['play', 'pause', 'reset'].includes(command)) {
      return { ok: false, error: 'Invalid command' };
    }
    this.settleExperiment(room);
    const exp = room.experiment;
    if (command === 'reset') {
      exp.runId += 1;
      room.experimentTools.focusTime = null;
      room.experimentTools.highlight = null;
      room.toolVersion += 1;
      exp.status = 'idle';
      exp.simTime = 0;
      exp.updatedAt = Date.now();
    } else if (command === 'play') {
      if (exp.status === 'finished') return { ok: false, error: 'Run finished, reset first' };
      exp.status = 'running';
      exp.updatedAt = Date.now();
    } else {
      if (exp.status !== 'running') return { ok: false, error: 'Not running' };
      exp.status = 'paused';
      exp.updatedAt = Date.now();
    }
    this.touch(room);
    return { ok: true, data: undefined };
  }

  /* ------------------------------ AI tutor ------------------------------- */

  /** C v0.5.1 manual tools. Source is always supplied by this server. */
  experimentTool(code: string, payload: {requestId?:unknown;command?:unknown}): Ack<any> {
    const room=this.rooms.get(code);
    if(!room)return {ok:false,error:'Room not found'};
    const id=payload?.requestId;
    if(typeof id!=='string'||id.length<8||id.length>100)return {ok:false,error:'Invalid requestId'};
    if(room.toolRequests.has(id))return {ok:true,data:room.toolRequests.get(id)};
    if(room.questionOpen||!['predict_rc','reveal_rc','resistance','lc'].includes(room.stage))return {ok:false,error:'Close prediction before using experiment tools'};
    try {
      this.settleExperiment(room);
      const outcome=executeExperimentTool(room.experiment,room.experimentTools,payload.command,{now:Date.now(),source:'manual'});
      room.experiment=outcome.experiment;room.experimentTools=outcome.tools;
      room.toolVersion += 1;
      room.toolRequests.set(id,outcome.result);
      if(room.toolRequests.size>100)room.toolRequests.delete(room.toolRequests.keys().next().value!);
      this.touch(room);return {ok:true,data:outcome.result};
    }catch(e){return {ok:false,error:e instanceof Error?e.message:'Invalid experiment tool'};}
  }

  /** Host-triggered analysis. Returns the binding so index.ts can await the
   *  AI call and discard the response if the class state moved on. */
  beginTutor(code: string): Ack<{
    input: TutorInput;
    binding: { questionId: string; stage: Stage; answerVersion: number };
  }> {
    const room = this.rooms.get(code);
    if (!room) return { ok: false, error: 'Room not found' };
    if (room.tutorInFlight) return { ok: false, error: 'An analysis is already running' };
    if (!room.question) return { ok: false, error: 'No question in this stage' };
    if (room.questionOpen) return { ok: false, error: 'Close the question first' };
    const now = Date.now();
    if (now - room.tutorLastRequestAt < TUTOR_COOLDOWN_MS) {
      return { ok: false, error: 'Please wait before requesting another analysis' };
    }
    const aggregate: Aggregate = room.aggregate ?? {
      submitted: 0,
      eligible: 0,
      counts: {},
    };
    // Anonymous: no participantId, nickname or token ever reaches the model.
    const explanations = [...(room.submissions.get(room.question.id)?.values() ?? [])]
      .map((s) => s.explanation.slice(0, MAX_EXPLANATION))
      .filter((s) => s.length > 0)
      .slice(0, 20);
    const input: TutorInput = {
      stage: room.stage,
      question: room.question,
      aggregate,
      explanations,
      params: { ...room.experiment.params },
      physicsFacts: physicsFacts(room.experiment.params),
      previousDecisions: [...room.previousDecisions],
      answerVersion: room.answerVersion,
    };
    const binding = {
      questionId: room.question.id,
      stage: room.stage,
      answerVersion: room.answerVersion,
    };
    room.tutorBinding = binding;
    room.tutorInFlight = true;
    room.tutorLastRequestAt = now;
    return { ok: true, data: { input, binding } };
  }

  /** Deliberately bound to question/stage/answerVersion, NOT snapshot revision
   *  (which changes every 500 ms during playback). */
  commitTutor(
    code: string,
    binding: { questionId: string; stage: Stage; answerVersion: number },
    decision: TutorProposal
  ): boolean {
    const room = this.rooms.get(code);
    if (!room) return false;
    room.tutorInFlight = false;
    if (!room.tutorBinding) return false;
    const b = room.tutorBinding;
    const stillValid =
      b.questionId === binding.questionId &&
      b.stage === binding.stage &&
      b.answerVersion === binding.answerVersion &&
      room.stage === binding.stage &&
      room.answerVersion === binding.answerVersion &&
      !room.questionOpen;
    if (!stillValid) return false;
    if(decision.toolCommand){
      try{
        validateToolCommand(decision.toolCommand);
        if(!['retry_experiment','explain'].includes(decision.action))return false;
        if(decision.toolCommand.action==='compare_resistance'&&room.stage!=='resistance')return false;
        if(!['resistance','reveal_rc','lc'].includes(room.stage))return false;
        // Validate ranges against the actual current experiment without committing the returned state.
        executeExperimentTool(room.experiment,room.experimentTools,decision.toolCommand,{now:Date.now(),source:decision.source==='ai'?'ai':'manual'});
      }catch{return false;}
    }
    room.pendingTutor = {...decision,proposalId:this.newToken()};
    return true;
  }

  cancelTutor(code: string): void {
    const room = this.rooms.get(code);
    if (room) room.tutorInFlight = false;
  }

  pendingDecision(code: string): TutorProposal | null {
    return this.rooms.get(code)?.pendingTutor ?? null;
  }

  /** Apply executes ONLY the last validated decision, never an arbitrary
   *  client-supplied instruction. */
  applyTutor(code: string, proposalId?:unknown): Ack {
    const room = this.rooms.get(code);
    if (!room) return { ok: false, error: 'Room not found' };
    if(typeof proposalId==='string'&&room.appliedProposals.has(proposalId))return {ok:true,data:undefined};
    const decision = room.pendingTutor;
    if (!decision) return { ok: false, error: 'No tutor decision to apply' };
    if(proposalId!==undefined&&proposalId!==decision.proposalId)return {ok:false,error:'This proposal has expired. Analyze again.'};
    const binding=room.tutorBinding;
    if(!binding||binding.questionId!==room.question?.id||binding.stage!==room.stage||binding.answerVersion!==room.answerVersion||room.questionOpen)return {ok:false,error:'This proposal is stale. Analyze again.'};
    if(decision.action==='final_check'&&room.closedQuestionIds.has(POST_QUESTION_ID))return {ok:false,error:'Final question is already complete. Continue to results.'};
    room.feedbackToken=null;room.feedbackJob=null;

    if(decision.toolCommand){
      const outcome=executeExperimentTool(room.experiment,room.experimentTools,decision.toolCommand,{now:Date.now(),source:decision.source==='ai'?'ai':'manual'});
      room.experiment=outcome.experiment;room.experimentTools=outcome.tools;room.toolVersion+=1;
      const id=decision.proposalId!;
      room.feedbackToken=id;
      room.feedbackJob={id,questionId:room.question!.id,stage:room.stage,answerVersion:room.answerVersion,toolVersion:room.toolVersion,decision,result:outcome.result};
      room.tutor={...decision,action:'explain',followup:null,evidence:toolResultMessage(outcome.result),message:'The approved tool has run. Use these confirmed model values to revisit the prediction.'};
      room.appliedProposals.add(id);room.previousDecisions.push(decision);room.pendingTutor=null;room.tutorBinding=null;this.touch(room);
      return {ok:true,data:undefined};
    }

    switch (decision.action) {
      case 'explain':
        // Display only; no stage or experiment change.
        break;
      case 'retry_experiment':
        room.experiment = {
          ...room.experiment,
          status: 'idle',
          simTime: 0,
          updatedAt: Date.now(),
          runId: room.experiment.runId + 1,
        };
        break;
      case 'ask_followup': {
        if (room.followupCount >= MAX_FOLLOWUP_ROUNDS) {
          return { ok: false, error: 'Followup limit reached (max 2)' };
        }
        room.followupCount += 1;
        const id = `followup_${room.code}_${room.followupCount}`;
        const followup: Question = {
          id,
          kind: 'followup',
          prompt: decision.followup ?? decision.message,
          options: [],
          requiresExplanation: true,
        };
        room.eligibleByQuestion.set(id, new Set([...room.participants.values()].filter(p=>p.connected).map(p=>p.id)));
        room.submissions.set(id, new Map());
        room.question = followup;
        room.questionOpen = true;
        room.aggregate = null;
        this.bumpAnswerVersion(room);
        break;
      }
      case 'advance_lc':
        room.experimentTools = emptyTools();
        room.stage = 'lc';
        room.question = null;
        room.questionOpen = false;
        room.aggregate = null;
        room.experiment = this.freshExperiment('lc');
        room.experiment.mode = 'lc';
        room.experiment.playbackRate = this.playbackRate(
          'lc', room.experiment.params, room.experiment.stopAtFirstZero
        );
        break;
      case 'final_check': {
        room.experimentTools = emptyTools();
        room.stage = 'final_check';
        room.question = null;
        room.questionOpen = false;
        room.aggregate = null;
        room.experiment = this.freshExperiment('final_check');
        // Open the final verification question right away.
        const finalQ = QUESTION_BANK[POST_QUESTION_ID];
        room.question = finalQ;
        room.questionOpen = true;
        room.eligibleByQuestion.set(finalQ.id, new Set([...room.participants.values()].filter(p=>p.connected).map(p=>p.id)));
        room.submissions.set(finalQ.id, new Map());
        this.bumpAnswerVersion(room);
        break;
      }
      default:
        return { ok: false, error: 'Unknown tutor action' };
    }

    room.tutor = decision;
    if(decision.proposalId)room.appliedProposals.add(decision.proposalId);
    room.previousDecisions.push(decision);
    room.pendingTutor = null;
    room.tutorBinding = null;
    this.touch(room);
    return { ok: true, data: undefined };
  }

  /** Manual override always available to the host: drop the pending decision. */
  clearTutor(code: string): Ack {
    const room = this.rooms.get(code);
    if (!room) return { ok: false, error: 'Room not found' };
    room.pendingTutor = null;
    room.tutorBinding = null;
    room.tutorInFlight = false;
    room.feedbackToken = null;
    room.feedbackJob = null;
    this.touch(room);
    return { ok: true, data: undefined };
  }

  takeToolFeedback(code:string):ToolFeedbackJob|null {
    const room=this.rooms.get(code);if(!room)return null;
    const job=room.feedbackJob;room.feedbackJob=null;return job;
  }

  commitToolFeedback(code:string,job:ToolFeedbackJob,feedback:TutorProposal):boolean {
    const room=this.rooms.get(code);
    if(!room||room.feedbackToken!==job.id||room.question?.id!==job.questionId||room.stage!==job.stage||room.answerVersion!==job.answerVersion||room.toolVersion!==job.toolVersion)return false;
    room.tutor={...feedback,evidence:toolResultMessage(job.result),action:'explain',followup:null};room.feedbackToken=null;this.touch(room);return true;
  }

  /* -------------------------------- housekeeping -------------------------- */

  pruneIdle(now = Date.now()): number {
    let removed = 0;
    for (const [code, room] of this.rooms) {
      if (now - room.lastActivityAt > ROOM_IDLE_TTL_MS) {
        this.rooms.delete(code);
        removed += 1;
      }
    }
    return removed;
  }

  /** Exposed for A/C: the frozen component props contract. */
  static readonly experimentPanelPropsShape: ReadonlyArray<keyof ExperimentPanelProps> = [
    'experiment', 'clockOffsetMs', 'role', 'onControl', 'onParamsChange',
    'onStopAtFirstZeroChange',
  ];

  static readonly preQuestionId = PRE_QUESTION_ID;
  static readonly postQuestionId = POST_QUESTION_ID;
}
