export * from '../shared/physics';
import { sampleRC, initialEnergy } from '../shared/physics';
import type { PhysicsParams } from '../shared/contracts';

/** Human-readable, trusted physics facts handed to the AI tutor. */
export function physicsFacts(params: PhysicsParams): string {
  initialEnergy(params);
  const { C, V0, R } = params;
  const E0 = (C * V0 * V0) / 2;
  const tau = (R * C) / 2;
  const omega = Math.sqrt(2 / (params.L * C));
  const tStar = Math.PI / omega;
  const settled = sampleRC(params, 10 * tau);
  return [
    `RC (two identical capacitors, A starts at ${V0} V, B at 0 V, no battery during transfer):`,
    `tau = R*C/2 = ${tau.toExponential(3)} s`,
    `Steady state: vA = vB = ${(V0 / 2).toFixed(3)} V`,
    `Initial energy E0 = ${(E0 * 1e3).toFixed(3)} mJ`,
    `Final eA = eB = ${(E0 / 4 * 1e3).toFixed(3)} mJ each (E0/4 each)`,
    `Total retained in the two capacitors = 50% of E0 = ${(E0 / 2 * 1e3).toFixed(3)} mJ`,
    `Energy delivered to capacitor B alone = 25% of E0`,
    `Heat dissipated = 50% of E0 = ${(E0 / 2 * 1e3).toFixed(3)} mJ`,
    `Changing R changes tau and peak current, but NOT the final heat or final voltages`,
    `Do NOT call the 50% retained energy "transfer efficiency"`,
    `LC (ideal lossless inductor, omega = sqrt(2/(LC)) = ${omega.toExponential(3)} rad/s):`,
    `At t* = pi/omega = ${tStar.toExponential(3)} s: vA = 0, vB = ${V0} V, i = 0, heat = 0`,
    `Opening at that first zero-current instant freezes B with the full E0 (ideal model only)`,
    `If not opened, energy flows back and the system returns to its initial state at 2t*`,
    `settled RC check: eA=${(settled.eA * 1e3).toFixed(4)} mJ, eB=${(settled.eB * 1e3).toFixed(4)} mJ, heat=${(settled.heat * 1e3).toFixed(4)} mJ`,
  ].join('\n');
}
