/**
 * ChargeQuest - correct answers, SERVER SIDE ONLY. Owner: B.
 *
 * Handoff v2 section 13, item 6: correct answers must never be shipped in the
 * public question bank (shared/questions.ts) or the browser bundle.
 * The browser learns correctness only through session:results (aggregate paired
 * counts) and its own "correct / review" card.
 *
 * Option IDs must match the frozen contract:
 *   rc_v1         -> quarter | half | all | unsure
 *   resistance_v1 -> less | same | more | unsure
 *   final_v1      -> a | b | c | d
 */

export const ANSWER_KEY: Record<string, string> = {
  rc_v1: 'half',
  resistance_v1: 'same',
  final_v1: 'a',
};

export function isCorrect(questionId: string, optionId: string | null): boolean {
  const expected = ANSWER_KEY[questionId];
  if (!expected || optionId === null) return false;
  return optionId === expected;
}

/** Only the two concept-check questions participate in the paired comparison. */
export const PAIR_PRE = 'rc_v1';
export const PAIR_POST = 'final_v1';
