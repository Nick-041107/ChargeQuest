/**
 * ChargeQuest - HTTP + Socket.IO entry point. Owner: B.
 * Handoff v2 sections 5, 9, 10.
 *
 * Dev:  Vite proxies /api and /socket.io here (port 3001).
 * Prod: this single Node process serves client/dist AND the live API.
 * One process, in-memory rooms. A restart clears all rooms.
 */

import 'dotenv/config';
import http from 'node:http';
import path from 'node:path';
import fs from 'node:fs';
import express, { type Request, type Response } from 'express';
import { Server, type Socket } from 'socket.io';
import type {
  Ack,
  ClientSession,
  HostExperimentControlPayload,
  HostOpenQuestionPayload,
  HostSetExperimentPayload,
  HostSetStagePayload,
  RoomSnapshot,
  SocketAuth,
  Stage,
  StudentSubmitPayload,
  TutorDecision,
} from '../shared/contracts';
import { diagnoseClass } from './ai';
import { explainToolResult } from './toolFeedback';
import { RoomStore } from './rooms';
import { isCorrect } from './questionsAnswerKey';

const PORT = Number(process.env.PORT ?? 3001);
const CLIENT_DIST = path.resolve(__dirname, '../../client/dist');

const app = express();
app.use(express.json({ limit: '16kb' }));
const server = http.createServer(app);
const io = new Server(server, {
  // Production is same-origin; dev uses the Vite proxy. No wide-open CORS.
  cors: { origin: false },
  maxHttpBufferSize: 32 * 1024,
});

const store = new RoomStore();

function ok<T>(res: Response, data: T): void {
  res.json({ ok: true, data } satisfies Ack<T>);
}
function fail(res: Response, status: number, error: string): void {
  res.status(status).json({ ok: false, error } satisfies Ack<never>);
}
function ackOk(): Ack {
  return { ok: true, data: undefined };
}
function ackFail(error: string): Ack {
  return { ok: false, error };
}

/* --------------------------------- HTTP --------------------------------- */

app.get('/api/health', (_req, res) => {
  ok(res, { status: 'ok' });
});

app.post('/api/rooms', (_req, res) => {
  const result = store.createRoom();
  if (!result.ok) return fail(res, 500, result.error);
  ok(res, result.data);
});

app.post('/api/rooms/:code/join', (req: Request, res: Response) => {
  const nickname = typeof req.body?.nickname === 'string' ? req.body.nickname : '';
  const result = store.join(req.params.code, nickname);
  if (!result.ok) return fail(res, 400, result.error);
  ok(res, result.data);
});

/**
 * Host-only diagnosis. Reads the server's OWN stored answers - never accepts
 * an aggregate from the client. Key stays on the server.
 */
app.post('/api/rooms/:code/tutor', async (req: Request, res: Response) => {
  const authHeader = req.headers.authorization ?? '';
  const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7) : '';
  const room = store.get(req.params.code);
  if (!room) return fail(res, 404, 'Room not found');
  if (!token || token !== room.hostToken) return fail(res, 403, 'Host token required');

  const begun = store.beginTutor(req.params.code);
  if (!begun.ok) {
    return fail(res, begun.error === 'An analysis is already running' ? 429 : 400, begun.error);
  }

  const { input, binding } = begun.data;
  try {
    const decision: TutorDecision = await diagnoseClass(input);
    const committed = store.commitTutor(req.params.code, binding, decision);
    if (!committed) {
      return fail(res, 409, 'Class state changed; this analysis is stale. Request again.');
    }
    io.to(hostRoom(req.params.code)).emit('session:host',store.hostPrivate(req.params.code));
    ok(res, store.pendingDecision(req.params.code));
  } catch {
    store.cancelTutor(req.params.code);
    fail(res, 502, 'Tutor unavailable');
  }
});

/* ------------------------------- Socket.IO -------------------------------- */

function roomName(code: string): string {
  return `room:${code}`;
}
function privateRoom(code: string, participantId: string): string {
  return `${roomName(code)}:p:${participantId}`;
}
function hostRoom(code: string): string {
  return `${roomName(code)}:host`;
}

// Additive result fields; the frozen public contract is unchanged.
function resultReport(code:string, participantId:string|null) {
  const report=store.results(code,participantId);
  return {...report,myAnswers:report.mySubmissions.map(s=>({questionId:s.questionId,explanation:s.explanation,correct:s.questionId.startsWith('followup_')?undefined:isCorrect(s.questionId,s.optionId)}))};
}

function broadcast(code: string): void {
  const snap = store.snapshot(code);
  if (!snap) return;
  io.to(roomName(code)).emit('room:snapshot', snap);
  io.to(hostRoom(code)).emit('session:host',store.hostPrivate(code));

  // Private data goes ONLY to the owning socket, never into the public snapshot.
  for (const p of snap.participants) {
    io.to(privateRoom(code, p.id)).emit(
      'session:private',
      store.privateSession(code, p.id)
    );
  }
  if (snap.stage === 'results') {
    io.to(hostRoom(code)).emit('session:results',resultReport(code,null));
    for (const p of snap.participants) {
      io.to(privateRoom(code, p.id)).emit(
        'session:results',
        resultReport(code, p.id)
      );
    }
  }
}

function requireHost(socket: Socket): ClientSession | null {
  const s = socket.data.session as ClientSession | undefined;
  return s && s.role === 'host' ? s : null;
}
function requireStudent(socket: Socket): ClientSession | null {
  const s = socket.data.session as ClientSession | undefined;
  return s && s.role === 'student' ? s : null;
}

io.use((socket, next) => {
  const auth = socket.handshake.auth as Partial<SocketAuth>;
  if (!auth || typeof auth.roomCode !== 'string' || typeof auth.token !== 'string') {
    return next(new Error('Missing room credentials'));
  }
  const session = store.resolve({ roomCode: auth.roomCode, token: auth.token });
  if (!session) return next(new Error('Invalid room or token'));
  socket.data.session = session;
  next();
});

io.on('connection', (socket: Socket) => {
  const session = socket.data.session as ClientSession;
  const code = session.roomCode;

  socket.join(roomName(code));
  if (session.role === 'host') {
    socket.join(hostRoom(code));
    if(store.snapshot(code)?.stage==='results')socket.emit('session:results',resultReport(code,null));
  } else if (session.participantId) {
    socket.join(privateRoom(code, session.participantId));
    store.setConnected(code, session.participantId, true);
  }

  // Initial state right after a verified handshake.
  const snap = store.snapshot(code);
  if (snap) socket.emit('room:snapshot', snap);
  if (session.participantId) {
    socket.emit('session:private', store.privateSession(code, session.participantId));
    if (snap?.stage === 'results') {
      socket.emit('session:results', resultReport(code, session.participantId));
    }
  }
  broadcast(code);

  socket.on('disconnect', () => {
    if (session.participantId) {
      store.setConnected(code, session.participantId, (io.sockets.adapter.rooms.get(privateRoom(code,session.participantId))?.size??0)>0);
      broadcast(code);
    }
  });

  /** Every event has an acknowledgement callback. No silent failures. */
  type AckCb = (result: Ack) => void;
  const withAck = (fn: () => Ack, cb?: AckCb): void => {
    let result: Ack;
    try {
      result = fn();
    } catch (err) {
      result = ackFail(err instanceof Error ? err.message : 'Internal error');
    }
    if (typeof cb === 'function') cb(result);
    if (result.ok) broadcast(code);
  };

  socket.on('host:set_stage', (p: HostSetStagePayload, cb?: AckCb) => {
    withAck(() => {
      if (!requireHost(socket)) return ackFail('Host permission required');
      return store.setStage(code, p?.stage as Stage);
    }, cb);
  });

  socket.on('host:open_question', (p: HostOpenQuestionPayload, cb?: AckCb) => {
    withAck(() => {
      if (!requireHost(socket)) return ackFail('Host permission required');
      if (!p || typeof p.questionId !== 'string') return ackFail('Invalid questionId');
      return store.openQuestion(code, p.questionId);
    }, cb);
  });

  socket.on('host:close_question', (_p: unknown, cb?: AckCb) => {
    withAck(() => {
      if (!requireHost(socket)) return ackFail('Host permission required');
      return store.closeQuestion(code);
    }, cb);
  });

  socket.on('student:submit', (p: StudentSubmitPayload, cb?: AckCb) => {
    withAck(() => {
      const s = requireStudent(socket);
      if (!s || !s.participantId) return ackFail('Student permission required');
      if (!p || typeof p !== 'object') return ackFail('Invalid submission');
      return store.submit(code, s.participantId, p);
    }, cb);
  });

  socket.on('host:set_experiment', (p: HostSetExperimentPayload, cb?: AckCb) => {
    withAck(() => {
      if (!requireHost(socket)) return ackFail('Host permission required');
      if (!p || (p.mode !== 'rc' && p.mode !== 'lc')) return ackFail('Invalid mode');
      return store.setExperiment(code, p);
    }, cb);
  });

  socket.on('host:experiment_control', (p: HostExperimentControlPayload, cb?: AckCb) => {
    withAck(() => {
      if (!requireHost(socket)) return ackFail('Host permission required');
      if (!p || !['play', 'pause', 'reset'].includes(p.command)) {
        return ackFail('Invalid command');
      }
      return store.experimentControl(code, p.command);
    }, cb);
  });

  socket.on('host:apply_tutor', (p: {proposalId?:unknown}|undefined, cb?: AckCb) => {
    let applied=false;
    withAck(() => {
      if (!requireHost(socket)) return ackFail('Host permission required');
      const result=store.applyTutor(code,p?.proposalId);applied=result.ok;return result;
    }, cb);
    if(applied){
      const job=store.takeToolFeedback(code);
      if(job)void explainToolResult(job).then(feedback=>{if(store.commitToolFeedback(code,job,feedback))broadcast(code);});
    }
  });

  socket.on('host:clear_tutor', (_p: unknown, cb?: AckCb) => {
    withAck(() => {
      if (!requireHost(socket)) return ackFail('Host permission required');
      return store.clearTutor(code);
    }, cb);
  });

  socket.on('host:experiment_tool', (p: {requestId?:unknown;command?:unknown}, cb?: AckCb) => {
    withAck(()=>{
      if(!requireHost(socket))return ackFail('Host permission required');
      return store.experimentTool(code,p);
    },cb);
  });

  socket.on('session:sync', (_p: unknown, cb?: (r: Ack<RoomSnapshot>) => void) => {
    const snap = store.snapshot(code);
    if (!snap) {
      if (typeof cb === 'function') cb(ackFail('Room not found') as Ack<RoomSnapshot>);
      return;
    }
    if (session.participantId) {
      socket.emit('session:private', store.privateSession(code, session.participantId));
      if (snap.stage === 'results') {
        socket.emit('session:results', resultReport(code, session.participantId));
      }
    }
    if(session.role==='host'&&snap.stage==='results')socket.emit('session:results',resultReport(code,null));
    if(session.role==='host')socket.emit('session:host',store.hostPrivate(code));
    if (typeof cb === 'function') cb({ ok: true, data: snap });
    else socket.emit('room:snapshot', snap);
  });
});

/* ------------------- playback correction + idle cleanup ------------------- */

setInterval(() => {
  // 500 ms correction while a run is playing. Cheap for a ~30 person demo.
  for (const code of activeRoomCodes()) {
    const wasRunning=store.get(code)?.experiment.status==='running';
    const snap = store.snapshot(code);
    if (snap && (wasRunning||snap.experiment.status === 'running')) {
      io.to(roomName(code)).emit('room:snapshot', snap);
    }
  }
}, 500).unref();

setInterval(() => {
  store.pruneIdle();
}, 10 * 60 * 1000).unref();

// Track codes that have had a snapshot recently for the correction loop.
const seenCodes = new Set<string>();
function activeRoomCodes(): string[] {
  const codes: string[] = [];
  for (const [name] of io.sockets.adapter.rooms) {
    if (name.startsWith('room:') && !name.includes(':p:') && !name.endsWith(':host')) {
      const code = name.slice(5);
      codes.push(code);
      seenCodes.add(code);
    }
  }
  return codes;
}

require('./research.cjs').installResearchLab(app, store);

/* --------------------------- production static ---------------------------- */

if (fs.existsSync(CLIENT_DIST)) {
  app.use(express.static(CLIENT_DIST));
  app.get('*', (_req, res) => {
    res.sendFile(path.join(CLIENT_DIST, 'index.html'));
  });
} else {
  // Dev / pre-frontend: make it obvious the backend is alive.
  app.get('/', (_req, res) => {
    res.type('text/plain').send(
      'ChargeQuest backend is running. Frontend build not found - run "npm run dev" for Vite, or "npm run build" for production.'
    );
  });
}

server.listen(PORT, () => {
  console.log(`ChargeQuest backend listening on http://localhost:${PORT}`);
  console.log('Rooms are held in MEMORY only - restarting the server clears all data.');
});
