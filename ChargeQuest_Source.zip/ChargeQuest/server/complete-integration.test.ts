import { test } from 'node:test';
import assert from 'node:assert/strict';
import { RoomStore } from './rooms';
import { diagnoseClass } from './ai';
import { explainToolResult } from './toolFeedback';
import type { TutorProposal } from '../shared/extensions';

function readyRoom(){
  const store=new RoomStore(),created=store.createRoom();assert(created.ok);const code=created.data.code;
  const p=store.join(code,'Alex');assert(p.ok);store.setConnected(code,p.data.participantId,true);
  store.setStage(code,'resistance');store.openQuestion(code,'resistance_v1');
  store.submit(code,p.data.participantId,{questionId:'resistance_v1',optionId:'less',explanation:'Alex predicts a smaller resistor gives less heat.',confidence:70});store.closeQuestion(code);
  return {store,code};
}
const toolDecision:TutorProposal={source:'ai',misconception:'Possible resistance-loss confusion',evidence:'The prediction is less heat.',message:'Let us compare the two resistances.',action:'retry_experiment',followup:null,toolCommand:{action:'compare_resistance',values:[100,10]}};

test('AI proposes C tool, approval executes once, actual results return to model, and feedback commits',async()=>{
  const env={...process.env},original=globalThis.fetch;
  process.env.AI_API_KEY='fixture-secret';process.env.AI_BASE_URL='https://fixture.invalid/v1';process.env.AI_MODEL='fixture-model';
  const requests:any[]=[];
  globalThis.fetch=async(_url,options)=>{
    const body=JSON.parse(String(options?.body));requests.push(body);
    const content=requests.length===1?JSON.stringify({...toolDecision,source:undefined}):JSON.stringify({message:'The shorter transient balances the larger current. Compare the final heat in both cases.'});
    return new Response(JSON.stringify({choices:[{message:{content}}]}),{status:200,headers:{'Content-Type':'application/json'}});
  };
  try{
    const {store,code}=readyRoom(),analysis=store.beginTutor(code);assert(analysis.ok);
    const decision=await diagnoseClass(analysis.data.input);assert.equal(decision.source,'ai');assert(decision.toolCommand);
    assert(store.commitTutor(code,analysis.data.binding,decision));const proposal=store.pendingDecision(code)!;assert(proposal.proposalId);
    assert.equal(store.snapshot(code)!.experimentTools.comparison,null);assert.equal(store.snapshot(code)!.tutor,null);
    assert(store.applyTutor(code,proposal.proposalId).ok);assert.equal(store.snapshot(code)!.experimentTools.task!.source,'ai');
    const run=store.snapshot(code)!.experiment.runId;assert(store.applyTutor(code,proposal.proposalId).ok);assert.equal(store.snapshot(code)!.experiment.runId,run);
    const job=store.takeToolFeedback(code)!;assert(job);assert.equal(store.takeToolFeedback(code),null);
    const feedback=await explainToolResult(job);assert.equal(feedback.source,'ai');assert(store.commitToolFeedback(code,job,feedback));
    const modelResult=JSON.parse(requests[1].messages[1].content).trusted_tool_result;
    assert.equal(modelResult.units,'SI');assert.equal(modelResult.cases[0].final.heat,.0025);assert.equal(modelResult.cases[1].final.heat,.0025);
    assert.match(store.snapshot(code)!.tutor!.evidence,/2.500 mJ/);
  }finally{globalThis.fetch=original;for(const key of ['AI_API_KEY','AI_BASE_URL','AI_MODEL']){if(env[key]===undefined)delete process.env[key];else process.env[key]=env[key];}}
});

test('invalid model tool and wrong-stage tools fall back without executing',async()=>{
  const original=globalThis.fetch,env={...process.env};process.env.AI_API_KEY='test';process.env.AI_BASE_URL='https://fixture.invalid';process.env.AI_MODEL='test';
  try{
    const {store,code}=readyRoom(),analysis=store.beginTutor(code);assert(analysis.ok);
    globalThis.fetch=async()=>new Response(JSON.stringify({choices:[{message:{content:JSON.stringify({...toolDecision,toolCommand:{action:'compare_resistance',values:[10,10]}})}}]}));
    assert.equal((await diagnoseClass(analysis.data.input)).source,'fallback');
    assert.equal(store.snapshot(code)!.experimentTools.comparison,null);
    const second=readyRoom();second.store.setStage(second.code,'predict_rc');second.store.openQuestion(second.code,'rc_v1');second.store.closeQuestion(second.code);const next=second.store.beginTutor(second.code);assert(next.ok);
    assert.equal(second.store.commitTutor(second.code,next.data.binding,toolDecision),false);
  }finally{globalThis.fetch=original;for(const key of ['AI_API_KEY','AI_BASE_URL','AI_MODEL']){if(env[key]===undefined)delete process.env[key];else process.env[key]=env[key];}}
});

test('stale approval and tool feedback cannot overwrite a new experiment or stage',()=>{
  const {store,code}=readyRoom(),analysis=store.beginTutor(code);assert(analysis.ok);
  assert(store.commitTutor(code,analysis.data.binding,toolDecision));const p=store.pendingDecision(code)!;
  assert(!store.applyTutor(code,'wrong-proposal').ok);assert(store.applyTutor(code,p.proposalId).ok);
  const job=store.takeToolFeedback(code)!;store.experimentTool(code,{requestId:'manual-change-123',command:{action:'clear_tools'}});
  assert(!store.commitToolFeedback(code,job,{...toolDecision,toolCommand:undefined,message:'Outdated.'}));
  store.setStage(code,'lc');assert(!store.applyTutor(code).ok);
});

test('host-only private state restores proposals and anonymizes examples; public snapshot contains neither',()=>{
  const {store,code}=readyRoom();const analysis=store.beginTutor(code);assert(analysis.ok);store.commitTutor(code,analysis.data.binding,toolDecision);
  const h=store.hostPrivate(code)!;assert(h.pendingTutor?.proposalId);assert.equal(h.explanationSamples.length,1);assert(!h.explanationSamples[0].includes('Alex'));assert(h.explanationSamples[0].includes('[name]'));
  const publicText=JSON.stringify(store.snapshot(code));assert(!publicText.includes('explanationSamples'));assert(!publicText.includes('pendingTutor'));assert(!publicText.includes('Alex predicts'));
});

test('failed model feedback uses computed values and labels fallback instead of inventing output',async()=>{
  const {store,code}=readyRoom(),analysis=store.beginTutor(code);assert(analysis.ok);store.commitTutor(code,analysis.data.binding,toolDecision);store.applyTutor(code);
  const original=globalThis.fetch;globalThis.fetch=async()=>{throw new Error('offline');};
  try{const feedback=await explainToolResult(store.takeToolFeedback(code)!);assert.equal(feedback.source,'fallback');assert.match(feedback.evidence,/100 Ω: final heat 2.500 mJ/);}finally{globalThis.fetch=original;}
});
