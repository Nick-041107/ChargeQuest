import { test } from 'node:test';
import assert from 'node:assert/strict';
import { RoomStore } from './rooms';
import { sampleRC as serverRC } from './physics';
import { sampleRC as sharedRC } from '../shared/physics';

test('C tool results are authoritative, duplicate requests are idempotent, and transitions clear tools',()=>{
  const store=new RoomStore(),created=store.createRoom();assert(created.ok);const code=created.data.code;
  assert(store.setStage(code,'resistance').ok);
  const request={requestId:'test-compare-1',command:{action:'compare_resistance',values:[100,10]}};
  const first=store.experimentTool(code,request);assert(first.ok);assert.equal(first.data.cases[0].peakCurrent,.1);assert.equal(first.data.cases[1].peakCurrent,1);
  const run=store.snapshot(code)!.experiment.runId;
  const again=store.experimentTool(code,request);assert.deepEqual(again,first);assert.equal(store.snapshot(code)!.experiment.runId,run);
  const probe=store.experimentTool(code,{requestId:'test-probe-1',command:{action:'inspect_time',timeMs:.5,highlight:'current'}});assert(probe.ok);
  assert(Math.abs(probe.data.samples[0].i*1000-90.4837418)<1e-5);assert(Math.abs(probe.data.samples[1].i*1000-367.8794412)<1e-5);
  assert(store.setStage(code,'lc').ok);assert.equal(store.snapshot(code)!.experiment.mode,'lc');assert.equal(store.snapshot(code)!.experimentTools.comparison,null);
  assert.equal(serverRC,sharedRC);
});
test('offline student is excluded from opening eligibility; empty reasons are rejected',()=>{
  const store=new RoomStore(),created=store.createRoom();assert(created.ok);const code=created.data.code;
  const a=store.join(code,'Online'),b=store.join(code,'Offline');assert(a.ok&&b.ok);store.setConnected(code,a.data.participantId,true);
  store.setStage(code,'predict_rc');store.openQuestion(code,'rc_v1');
  assert(store.privateSession(code,a.data.participantId).eligibleQuestionIds.includes('rc_v1'));
  assert(!store.privateSession(code,b.data.participantId).eligibleQuestionIds.includes('rc_v1'));
  assert(!store.submit(code,a.data.participantId,{questionId:'rc_v1',optionId:'half',explanation:'',confidence:50}).ok);
});
test('host gets real paired metrics without student raw responses',()=>{
  const store=new RoomStore(),created=store.createRoom();assert(created.ok);const code=created.data.code;
  const a=store.join(code,'Learner');assert(a.ok);store.setConnected(code,a.data.participantId,true);
  for(const [stage,id,option] of [['predict_rc','rc_v1','all'],['final_check','final_v1','a']] as const){store.setStage(code,stage);store.openQuestion(code,id);store.submit(code,a.data.participantId,{questionId:id,optionId:option,explanation:'My explanation.',confidence:50});store.closeQuestion(code);}
  assert.deepEqual(store.results(code,null),{mySubmissions:[],pairedCount:1,preCorrect:0,postCorrect:1});
});
