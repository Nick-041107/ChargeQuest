import { useEffect, useRef, useState } from 'react';
import type { Socket } from 'socket.io-client';
import type { ClientSession, PrivateState, ResultsReport, ResultsPayload, RoomSnapshot, Submission, TutorDecision, HostPrivateState } from './types';
import { api, connect, request } from './transport';
import { createDemo, demoDecision, demoEvent, demoReport } from './demo';
export function useClassroom(session:ClientSession|null,demo:boolean) {
  const [snapshot,setSnapshot]=useState<RoomSnapshot|null>(()=>demo?createDemo():null);
  const [mySubmissions,setSubmissions]=useState<Submission[]>([]);
  const [eligibleIds,setEligibleIds]=useState<string[]|null>(null);
  const [results,setResults]=useState<ResultsReport|null>(null);
  const [tutorProposal,setProposal]=useState<TutorDecision|null>(null);
  const [hostPrivate,setHostPrivate]=useState<HostPrivateState|null>(null);
  const proposalBinding=useRef<{stage:string;questionId:string|null}|null>(null);
  const [status,setStatus]=useState('Connecting'),[error,setError]=useState(''),[busy,setBusy]=useState(false),[clockOffsetMs,setOffset]=useState(0);
  const socket=useRef<Socket|null>(null),latest=useRef(snapshot),answers=useRef(mySubmissions),pending=useRef(false);
  latest.current=snapshot;answers.current=mySubmissions;
  useEffect(()=>{
    if(demo){setStatus('Local preview');return;}
    if(!session)return;
    let active=true;
    const s=connect(session);socket.current=s;
    const accept=(next:RoomSnapshot)=>{if(active)setSnapshot(old=>!old||next.revision>=old.revision?next:old);};
    const sync=async()=>{const started=Date.now();try{const snap=await request<RoomSnapshot>(s,'session:sync');if(!active)return;accept(snap);setOffset(snap.serverNow-(started+Date.now())/2);}catch(e){if(active)setError((e as Error).message);}};
    s.on('connect',()=>{if(!active)return;setStatus('Connected');setError('');void sync();});
    s.on('room:snapshot',accept);
    s.on('session:host',(data:HostPrivateState)=>{if(active){proposalBinding.current={stage:data.stage,questionId:data.questionId};setProposal(data.pendingTutor);setHostPrivate(data);}});
    s.on('session:private',(data:PrivateState)=>{if(active){setSubmissions(data.mySubmissions);setEligibleIds(data.eligibleQuestionIds);}});
    s.on('session:results',(data:ResultsPayload)=>{if(active)setResults({paired:{n:data.pairedCount,beforeCorrect:data.preCorrect,afterCorrect:data.postCorrect},participantCount:latest.current?.participants.length??0,myAnswers:data.myAnswers??data.mySubmissions.map(a=>({questionId:a.questionId,explanation:a.explanation}))});});
    s.on('disconnect',()=>{if(active)setStatus('Reconnecting');});
    s.on('connect_error',(e:Error)=>{if(active){setStatus('Reconnecting');setError(e.message);}});
    s.connect();const timer=setInterval(()=>{if(s.connected)void sync();},30000);
    return()=>{active=false;clearInterval(timer);s.removeAllListeners();s.disconnect();socket.current=null;};
  },[session?.roomCode,session?.token,demo]);
  async function send(event:string,payload:Record<string,any>={}) {
    if(pending.current)throw new Error('Please wait for the current action to finish.');
    if(event.startsWith('host:')&&session?.role!=='host')throw new Error('Only the host can control the classroom.');
    pending.current=true;setBusy(true);setError('');
    try{
      if(demo){const s=latest.current!;if(event==='student:submit'){
        if(!s.questionOpen||s.question?.id!==payload.questionId)throw new Error('This question is closed.');
        const updated=[...answers.current.filter(a=>a.questionId!==payload.questionId),{...payload,participantId:'preview',submittedAt:Date.now()} as Submission];answers.current=updated;setSubmissions(updated);
      }else{let next=demoEvent(s,answers.current,event,payload);if(event==='host:apply_tutor'&&tutorProposal)next={...next,tutor:tutorProposal};setSnapshot(next);}}
      else {await request(socket.current,event,payload);if(event==='student:submit')await request(socket.current,'session:sync');}
      if(['host:set_stage','host:open_question','host:apply_tutor','host:clear_tutor'].includes(event))setProposal(null);
    }catch(e){setError((e as Error).message);throw e;}finally{pending.current=false;setBusy(false);}
  }
  async function analyze(){
    if(!session||session.role!=='host'||!latest.current?.question||latest.current.questionOpen||pending.current)return;
    pending.current=true;setBusy(true);setError('');const qid=latest.current.question.id,stage=latest.current.stage;
    try{const decision=demo?demoDecision(latest.current,answers.current):await api<TutorDecision>(`/api/rooms/${session.roomCode}/tutor`,{},session.token);
      if(latest.current?.question?.id===qid&&latest.current.stage===stage&&!latest.current.questionOpen){proposalBinding.current={stage,questionId:qid};setProposal(decision);}
    }catch(e){setError((e as Error).message);}finally{pending.current=false;setBusy(false);}
  }
  const eligible=demo?true:snapshot?.question&&eligibleIds?eligibleIds.includes(snapshot.question.id):undefined;
  const validProposal=tutorProposal&&proposalBinding.current?.stage===snapshot?.stage&&proposalBinding.current?.questionId===snapshot?.question?.id?tutorProposal:null;
  const explanationSamples=hostPrivate?.questionId===snapshot?.question?.id&&!snapshot?.questionOpen?hostPrivate?.explanationSamples??[]:[];
  return {snapshot,mySubmissions,eligible,results:demo?demoReport(mySubmissions):results,tutorProposal:validProposal,explanationSamples,status,error,busy,clockOffsetMs,send,analyze,clearError:()=>setError('')};
}
