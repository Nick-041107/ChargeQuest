/** Local launchers publish only an expiring origin, never credentials. */
export function readPublicOrigin(value:unknown,now=Date.now()):string|null {
  if(!value||typeof value!=='object')return null;
  const data=value as {origin?:unknown;expiresAt?:unknown};
  if(typeof data.origin!=='string'||typeof data.expiresAt!=='number'||!Number.isFinite(data.expiresAt)||data.expiresAt<=now)return null;
  try{
    const url=new URL(data.origin);
    if(url.protocol!=='https:'||url.username||url.password||url.pathname!=='/'||url.search||url.hash)return null;
    if(['localhost','127.0.0.1','[::1]'].includes(url.hostname))return null;
    return url.origin;
  }catch{return null;}
}
