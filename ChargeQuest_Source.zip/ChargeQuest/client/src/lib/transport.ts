import { io, type Socket } from 'socket.io-client';
import type { Ack, ClientSession } from './types';
export function newRequestId():string {
  if(typeof crypto.randomUUID==='function')return crypto.randomUUID();
  return Array.from(crypto.getRandomValues(new Uint8Array(16)),x=>x.toString(16).padStart(2,'0')).join('');
}
export async function api<T>(path:string, body:unknown, token?:string):Promise<T> {
  const response = await fetch(path, {method:'POST', headers:{'Content-Type':'application/json', ...(token?{Authorization:`Bearer ${token}`}:{})},body:JSON.stringify(body),signal:AbortSignal.timeout(180000)});
  let result:Ack<T>;
  try { result = await response.json(); } catch { throw new Error('The server did not return JSON. Check that the B backend is running.'); }
  if (!response.ok || !result.ok) throw new Error(!result.ok ? result.error : `Request failed (${response.status})`);
  return result.data;
}
export function connect(session:ClientSession) {
  return io({auth:{roomCode:session.roomCode,token:session.token},autoConnect:false,reconnection:true});
}
export function request<T=undefined>(socket:Socket|null,event:string,payload:unknown={}):Promise<T> {
  if (!socket?.connected) return Promise.reject(new Error('You are offline. Reconnect before trying again.'));
  return new Promise((resolve,reject)=>socket.timeout(10000).emit(event,payload,(error:Error|null,result:Ack<T>)=>{
    if(error) reject(new Error('No confirmation received. Syncing will check whether the action was saved.'));
    else if(!result || !result.ok) reject(new Error(result && !result.ok ? result.error : 'Invalid server acknowledgement.'));
    else resolve(result.data);
  }));
}
const sessionKey = (code:string,role:string) => `chargequest:${code}:${role}`;
export function saveSession(session:ClientSession) { sessionStorage.setItem(sessionKey(session.roomCode,session.role),JSON.stringify(session)); }
export function readSession(code:string,role:string):ClientSession|null {
  try { const s=JSON.parse(sessionStorage.getItem(sessionKey(code,role))||'null'); return s?.roomCode===code && s?.role===role && typeof s.token==='string' ? s : null; } catch {return null;}
}
