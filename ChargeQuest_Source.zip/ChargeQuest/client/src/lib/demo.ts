// Explicit local preview. No networking, real AI or real learning outcomes.
import type { Question, RoomSnapshot, Submission, ResultsReport, Stage, TutorDecision } from './types';
import { makeDemoExperiment, emptyTools, executeExperimentTool } from '../../../shared/experimentTools';
import { experimentDuration, timeAt } from '../../../shared/experimentView';
export const questions:Record<string,Question> = {
  rc_v1:{id:'rc_v1',kind:'rc_energy',prompt:'After the two capacitors settle, how much of the initial energy remains stored in both capacitors?',options:[{id:'quarter',label:'One quarter · 25%'},{id:'half',label:'One half · 50%'},{id:'all',label:'All of it · 100%'},{id:'unsure',label:'I’m not sure yet'}],requiresExplanation:true},
  resistance_v1:{id:'resistance_v1',kind:'resistance_loss',prompt:'Reduce the resistance from 100 Ω to 10 Ω. What happens to the total heat released after settling?',options:[{id:'less',label:'Less heat'},{id:'same',label:'The same heat'},{id:'more',label:'More heat'},{id:'unsure',label:'I’m not sure yet'}],requiresExplanation:true},
  final_v1:{id:'final_v1',kind:'final',prompt:'Two equal 100 μF capacitors start at 8 V and 0 V. After RC settling, what are their voltages and total retained energy?',options:[{id:'a',label:'4 V each · 50% retained'},{id:'b',label:'4 V each · 100% retained'},{id:'c',label:'8 V each · 100% retained'},{id:'d',label:'I’m not sure yet'}],requiresExplanation:true},
};
export function createDemo():RoomSnapshot { return {code:'104208',revision:1,serverNow:Date.now(),stage:'lobby',participants:[{id:'preview',nickname:'Preview learner (simulated)',connected:true}],question:null,questionOpen:false,aggregate:null,submittedCount:0,experiment:makeDemoExperiment(Date.now()),experimentTools:emptyTools(),tutor:null}; }
export function demoReport(answers:Submission[]):ResultsReport {
  // Correctness is supplied only by the live backend, never by a browser answer key.
  return {participantCount:1,paired:{n:0,beforeCorrect:0,afterCorrect:0},myAnswers:answers.map(a=>({questionId:a.questionId,explanation:a.explanation}))};
}
export function demoDecision(s:RoomSnapshot,answers:Submission[]):TutorDecision {
  const answer=answers.find(a=>a.questionId===s.question?.id);
  return {source:'fallback',misconception:answer?'A possible confusion between charge and stored energy.':'There is not enough evidence to identify a misconception.',evidence:answer?'One simulated learner submitted a response. This local preview does not analyze its meaning.':'No response to this question in the local preview.',message:'Compare the energy stored before and after connecting the capacitors. Then test a different resistance.',action:'explain',followup:null};
}
export function demoEvent(s:RoomSnapshot,answers:Submission[],event:string,p:Record<string,any>):RoomSnapshot {
  let next={...s,revision:s.revision+1,serverNow:Date.now()};
  if(event==='host:set_stage') {
    const stage=p.stage as Stage;
    next={...next,stage,question:stage==='reveal_rc'?s.question:null,questionOpen:false,aggregate:stage==='reveal_rc'?s.aggregate:null,tutor:null,experiment:{...makeDemoExperiment(Date.now()),mode:stage==='lc'?'lc':'rc',runId:s.experiment.runId+1},experimentTools:emptyTools()};
    if(stage==='lc') next.experiment.playbackRate=experimentDuration(next.experiment)/6;
    if(stage==='final_check') next.experiment.params.V0=8;
  }
  if(event==='host:open_question') {
    if(answers.some(a=>a.questionId===p.questionId) || (s.question?.id===p.questionId&&!s.questionOpen)) throw new Error('This preview question has already been used. Reset the preview to start again.');
    next={...next,question:questions[p.questionId]??{id:p.questionId,kind:'followup',prompt:p.prompt??'How is conserved charge different from stored energy?',options:[],requiresExplanation:true},questionOpen:true,aggregate:null,tutor:null};
  }
  if(event==='host:close_question') { const a=answers.filter(a=>a.questionId===s.question?.id);const counts:Record<string,number>={};a.forEach(x=>{if(x.optionId) counts[x.optionId]=(counts[x.optionId]??0)+1;});next={...next,questionOpen:false,aggregate:{eligible:1,submitted:a.length,counts}}; }
  if(event==='host:set_experiment') next={...next,experiment:{...s.experiment,...p,status:'idle',simTime:0,updatedAt:Date.now(),runId:s.experiment.runId+1},experimentTools:emptyTools()};
  if(event==='host:experiment_control') { const e={...s.experiment};e.simTime=p.command==='reset'?0:timeAt(e,Date.now());e.status=p.command==='play'?'running':p.command==='pause'?'paused':'idle';e.updatedAt=Date.now();if(p.command==='reset') {e.runId++;next.experimentTools={...(s.experimentTools??emptyTools()),focusTime:null,highlight:null};}next.experiment=e; }
  if(event==='host:experiment_tool') {const o=executeExperimentTool(s.experiment,s.experimentTools??emptyTools(),p.command,{now:Date.now(),source:'manual'});next={...next,experiment:o.experiment,experimentTools:o.tools};}
  if(event==='host:apply_tutor') next.tutor=null;
  return next;
}
