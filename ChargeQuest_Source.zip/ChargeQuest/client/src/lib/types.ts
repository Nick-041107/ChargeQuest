// UI adapters; frozen shared/contracts.ts remains unchanged.
export type { Ack, ClientSession, Question, Submission, Stage, Role, PhysicsParams, PhysicsSample, ExperimentState } from '../../../shared/contracts';
import type { RoomSnapshot as BaseSnapshot, PrivateSession, SessionResults } from '../../../shared/contracts';
import type { ExperimentToolsState } from '../../../shared/experimentTools';
export type { HostPrivateState } from '../../../shared/extensions';
export type { TutorProposal as TutorDecision } from '../../../shared/extensions';
import type { TutorProposal as TutorDecision } from '../../../shared/extensions';
export type RoomSnapshot = Omit<BaseSnapshot,'tutor'> & {tutor:TutorDecision|null;experimentTools?:ExperimentToolsState};
export type PrivateState = PrivateSession;
export type ResultsReport = {paired:{n:number;beforeCorrect:number;afterCorrect:number};participantCount:number;myAnswers:{questionId:string;correct?:boolean;explanation:string;feedback?:string}[]};
export type ResultsPayload = SessionResults & {myAnswers?:ResultsReport['myAnswers']};
