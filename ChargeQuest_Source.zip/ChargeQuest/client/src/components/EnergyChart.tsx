import type { PhysicsSample } from '../../../shared/physics';
import { energyMarkup } from '../../../shared/experimentView';
import './experiment.css';
export default function EnergyChart({ sample, initialEnergy }: {sample: PhysicsSample; initialEnergy: number}) {
  return <div className="cq-exp-root" dangerouslySetInnerHTML={{ __html: energyMarkup(sample, initialEnergy) }}/>;
}
export { EnergyChart };
