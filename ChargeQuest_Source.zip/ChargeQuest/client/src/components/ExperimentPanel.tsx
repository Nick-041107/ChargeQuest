import { useEffect, useRef, useState } from 'react';
import type { PhysicsParams } from '../../../shared/physics';
import { experimentMarkup, timeAt, experimentDuration, applyWaveProbe, clearWaveProbe, probeMarkup } from '../../../shared/experimentView';
import type { ExperimentState } from '../../../shared/experimentView';
import { comparisonMarkup, applyComparisonProbe, clearComparisonProbe, applyPinnedProbe } from '../../../shared/comparisonView';
import type { ExperimentToolsState } from '../../../shared/experimentTools';
import './experiment.css';

export type ExperimentPanelProps = {
  tools?: ExperimentToolsState;
  experiment: ExperimentState; clockOffsetMs: number; role: 'host' | 'student';
  onControl?: (command: 'play' | 'pause' | 'reset') => void;
  onParamsChange?: (params: PhysicsParams) => void;
  onStopAtFirstZeroChange?: (enabled: boolean) => void;
};
export default function ExperimentPanel({ experiment: e, clockOffsetMs, role, onControl, onParamsChange, onStopAtFirstZeroChange, tools }: ExperimentPanelProps) {
  const [now, setNow] = useState(() => Date.now());
  const viewRef = useRef<HTMLDivElement>(null);
  const pointerRef = useRef<{x:number;y:number} | null>(null);
  useEffect(() => {
    setNow(Date.now());
    if (e.status !== 'running') return;
    let frame = 0;
    const tick = () => { setNow(Date.now()); frame = requestAnimationFrame(tick); };
    frame = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frame);
  }, [e.status, e.runId, e.updatedAt]);
  const comparing = !!tools?.comparison && e.mode === 'rc';
  const restoreProbe = () => {
    const root = viewRef.current;
    if (!root) return;
    if (pointerRef.current) {
      if (comparing && tools) applyComparisonProbe(root, e, tools, pointerRef.current.x, pointerRef.current.y);
      else applyWaveProbe(root, e, pointerRef.current.x, pointerRef.current.y);
    } else if (tools?.focusTime !== null && tools?.focusTime !== undefined) {
      if (comparing) applyPinnedProbe(root,e,tools);
      else { const g=root.querySelector('[data-cq-probe]'); if(g){ g.innerHTML=probeMarkup(e,tools.focusTime,75);g.setAttribute('style','display:block;pointer-events:none'); } }
    }
  };
  useEffect(() => { restoreProbe(); }, [now, e, clockOffsetMs, tools]);
  const t = timeAt(e, now, clockOffsetMs);
  const atEnd = t >= experimentDuration(e);
  const mutable = e.status !== 'running';
  return <div className="cq-exp-root">
    {role === 'host' ? <div className="cq-exp-controls">
      <button disabled={!onControl || (atEnd && e.status !== 'idle')} onClick={() => onControl?.(e.status === 'running' ? 'pause' : 'play')}>{e.status === 'running' ? 'Pause' : 'Play'}</button>
      <button disabled={!onControl} onClick={() => onControl?.('reset')}>Reset</button>
      {e.mode === 'rc' && !comparing && <label>R <input aria-label="Resistance" type="range" min="10" max="1000" step="10" value={e.params.R} disabled={!mutable || !onParamsChange} onChange={ev => onParamsChange?.({ ...e.params, R: Number(ev.target.value) })}/>{e.params.R} Ω</label>}
      {e.mode === 'lc' && <label><input type="checkbox" checked={e.stopAtFirstZero} disabled={!mutable || !onStopAtFirstZeroChange} onChange={ev => onStopAtFirstZeroChange?.(ev.target.checked)}/>Open at first zero current</label>}
    </div> : <div className="cq-exp-observer">Live classroom experiment · controlled by your host</div>}
    <div ref={viewRef}
      onPointerMove={event => {
        pointerRef.current = { x: event.clientX, y: event.clientY };
        restoreProbe();
      }}
      onPointerLeave={() => { pointerRef.current = null; if (viewRef.current) { clearWaveProbe(viewRef.current); clearComparisonProbe(viewRef.current); } restoreProbe(); }}
      onScrollCapture={() => { pointerRef.current = null; if (viewRef.current) { clearWaveProbe(viewRef.current); clearComparisonProbe(viewRef.current); } restoreProbe(); }}
      dangerouslySetInnerHTML={{ __html: comparing && tools ? comparisonMarkup(e,tools,t) : experimentMarkup(e,t) }}/>
  </div>;
}
export { ExperimentPanel };
