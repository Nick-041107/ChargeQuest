import { useEffect, useState } from 'react';
import QRCode from 'qrcode';
import type { ClientSession, Question, Stage } from './lib/types';
import ExperimentPanel from './components/ExperimentPanel';
import { sampleRC, sampleLC } from '../../shared/physics';
import { api, readSession, saveSession, newRequestId } from './lib/transport';
import { useClassroom } from './lib/useClassroom';
import { readPublicOrigin } from './lib/shareLink';

const stages:{id:Stage;label:string;short:string;description:string}[]=[
  {id:'lobby',label:'Gather the class',short:'Welcome',description:'A shared experiment. An independent prediction. A surprising discovery.'},
  {id:'predict_rc',label:'Where does the energy go?',short:'Predict',description:'Two identical capacitors. One charged, one empty. Make your prediction before we connect them.'},
  {id:'reveal_rc',label:'Follow the missing energy',short:'Reveal',description:'Watch voltage, current and stored energy change together.'},
  {id:'resistance',label:'Less resistance. Less heat?',short:'Change R',description:'Change one variable. Compare what happens now with what remains at the end.'},
  {id:'lc',label:'Can we keep the energy?',short:'Explore LC',description:'An ideal inductor offers a different path. Timing the switch makes all the difference.'},
  {id:'final_check',label:'A new voltage. Your new prediction.',short:'Check',description:'Apply the idea to an 8 V starting point. Explain it in your own words.'},
  {id:'results',label:'What changed in your thinking?',short:'Reflect',description:'A concept check from this session, and a starting point for the next question.'},
];
const standalone=window.location.protocol==='file:';
const currentPath=()=>standalone?(window.location.hash.slice(1)||'/demo'):window.location.pathname+window.location.search;
function go(path:string){if(standalone)window.location.hash=path;else history.pushState({},'',path);window.dispatchEvent(new PopStateEvent('popstate'));}
function Brand(){return <a className="brand" href="/" onClick={e=>{e.preventDefault();go('/');}}><span className="brand-icon">ϟ</span>Charge<span>Quest</span></a>;}
function Arrow(){return <span aria-hidden="true">↗</span>;}
export default function App(){
  const [location,setLocation]=useState(currentPath);
  useEffect(()=>{const fn=()=>setLocation(currentPath());window.addEventListener('popstate',fn);window.addEventListener('hashchange',fn);return()=>{window.removeEventListener('popstate',fn);window.removeEventListener('hashchange',fn);};},[]);
  const url=new URL(location,standalone?'http://preview.local':window.location.origin), path=url.pathname;
  const room=path.match(/^\/(host|room)\/(\d{6})\/?$/);
  if(path==='/demo')return <Classroom key="demo" demo initialSession={{role:'host',token:'local-preview',participantId:null,roomCode:'104208'}}/>;
  if(room){const role=room[1]==='host'?'host':'student';const session=readSession(room[2],role);return session?<Classroom key={`${room[2]}-${role}`} demo={false} initialSession={session}/>:<Landing joinCode={room[2]} missingSession={role==='host'}/>;}
  return <Landing joinCode={path==='/join'?(url.searchParams.get('code')??''):undefined}/>;
}
function Landing({joinCode,missingSession=false}:{joinCode?:string;missingSession?:boolean}){
  const [code,setCode]=useState(joinCode??''),[nickname,setNickname]=useState(''),[error,setError]=useState(''),[busy,setBusy]=useState(false);
  const [tab,setTab]=useState(joinCode!==undefined?'join':'host');
  async function submit(){setBusy(true);setError('');try{
    if(tab==='host') {const data=await api<{code:string;hostToken:string}>('/api/rooms',{});saveSession({roomCode:data.code,token:data.hostToken,participantId:null,role:'host'});go(`/host/${data.code}`);}
    else {const data=await api<{participantId:string;studentToken:string}>(`/api/rooms/${code}/join`,{nickname:nickname.trim()});saveSession({roomCode:code,token:data.studentToken,participantId:data.participantId,role:'student'});go(`/room/${code}`);}
  }catch(e){setError((e as Error).message);}finally{setBusy(false);}}
  return <div className="landing"><header className="topbar"><Brand/><span className="eyebrow">THE CIRCUIT CLASSROOM</span><a className="text-link" href="/join" onClick={e=>{e.preventDefault();go('/join');}}>Join a room <Arrow/></a></header>
    <main className="landing-main"><section className="hero"><div className="overline"><span className="dot"/> A LITTLE CIRCUIT. A BIG QUESTION.</div><h1>Energy has<br/>a few <em>surprises.</em></h1><p className="hero-copy">Predict together. Watch it happen.<br/>Discover what your intuition missed.</p>
      <div className="hero-circuit" aria-label="Two equal capacitors, one at 10 volts and one at zero volts"><div><span className="mini-label">CAPACITOR A</span><strong>10 <small>V</small></strong><div className="capacitor charged">‖</div><span>Charged. Ready.</span></div><div className="wire"><span>R</span><svg viewBox="0 0 180 50" aria-hidden="true"><path d="M0 25h45l8-13 14 26 14-26 14 26 14-26 14 26 8-13h49"/></svg><span className="unknown">What happens next?</span></div><div><span className="mini-label">CAPACITOR B</span><strong>0 <small>V</small></strong><div className="capacitor">‖</div><span>Empty. For now.</span></div></div>
      <div className="hero-tags"><span>Independent thinking</span><span>Shared discovery</span><span>No account needed</span></div></section>
    <section className="entry-card"><div className="tabs"><button aria-pressed={tab==='host'} onClick={()=>setTab('host')}>Host a class</button><button aria-pressed={tab==='join'} onClick={()=>setTab('join')}>Join a class</button></div>
      <span className="eyebrow">{tab==='host'?'FOR THE CURIOUS CLASSROOM':'BRING YOUR INTUITION'}</span><h2>{tab==='host'?'Start a shared discovery.':'You’re in the right place.'}</h2><p>{tab==='host'?'Create a room and invite your students. You guide the experiment; everyone gets a voice.':'Enter your room code and choose a nickname. Your first prediction is yours alone.'}</p>
      {missingSession&&<div className="notice">The host session is missing in this browser tab. Return to the original host tab, or create a new room.</div>}
      {standalone&&<div className="notice">This downloaded preview runs locally. Use “Try the local preview” below. Live rooms need the B backend.</div>}
      <form onSubmit={e=>{e.preventDefault();void submit();}}>{tab==='join'&&<><label htmlFor="room-code">Room code</label><input id="room-code" inputMode="numeric" autoComplete="off" pattern="[0-9]{6}" maxLength={6} value={code} onChange={e=>setCode(e.target.value.replace(/\D/g,''))} placeholder="6-digit code" required/><label htmlFor="nickname">Your nickname</label><input id="nickname" maxLength={24} minLength={1} value={nickname} onChange={e=>setNickname(e.target.value)} placeholder="What should we call you?" required/></>}
      {error&&<div className="error" role="alert">{error}</div>}<button className="primary wide" disabled={standalone||busy||(tab==='join'&&(code.length!==6||!nickname.trim()))}>{busy?'Connecting…':tab==='host'?'Create a classroom':'Join classroom'} <Arrow/></button></form>
      <div className="preview-entry"><span>Want to look around first?</span><button className="text-link" onClick={()=>go('/demo')}>Try the local preview <span>→</span></button><small>Sample classroom · no backend or online AI</small></div>
    </section></main><footer className="footer"><span>Think. Test. Discover.</span><span>Temporary rooms · data clears when the server restarts</span></footer></div>;
}
function Invite({code,demo}:{code:string;demo:boolean}){
  const loopback=['localhost','127.0.0.1','[::1]'].includes(window.location.hostname);
  const [publicOrigin,setPublicOrigin]=useState<string|null>(null);
  const origin=publicOrigin??(!loopback?window.location.origin:null);
  const url=origin?`${origin}/join?code=${code}`:null;
  const [qr,setQr]=useState(''),[copied,setCopied]=useState(false),[copyError,setCopyError]=useState('');
  useEffect(()=>{
    if(demo||standalone)return;
    let active=true;
    const sync=async()=>{try{const response=await fetch('/public-access.json',{cache:'no-store'});const value=response.ok?await response.json():null;if(active)setPublicOrigin(readPublicOrigin(value));}catch{if(active)setPublicOrigin(null);}};
    void sync();const timer=setInterval(sync,10000);return()=>{active=false;clearInterval(timer);};
  },[demo]);
  useEffect(()=>{let active=true;setQr('');setCopied(false);if(!demo&&url)QRCode.toDataURL(url,{width:160,margin:1,color:{dark:'#173c3b',light:'#ffffff'}}).then(data=>{if(active)setQr(data);}).catch(()=>{});return()=>{active=false;};},[url,demo]);
  return <div className="invite card"><div><span className="eyebrow">{demo?'SAMPLE ROOM CODE':'INVITE YOUR CLASS'}</span><div className="room-code">{code.slice(0,3)} {code.slice(3)}</div><p>{demo?'Preview only. Invite links require the B backend.':url?(origin?.startsWith('https:')?'Public link · scan to join from another network.':'Same Wi-Fi link · phones must be on the same network.'):'Phone sharing is not running yet.'}</p>{!demo&&url&&<><input aria-label="Join link" readOnly value={url} onFocus={e=>e.target.select()}/><button className="secondary" onClick={async()=>{try{await navigator.clipboard.writeText(url);setCopied(true);setCopyError('');}catch{setCopyError('Select and copy the link above.');}}}>{copied?'Link copied ✓':'Copy join link'}</button>{copyError&&<small role="status">{copyError}</small>}</>}{!demo&&!url&&<div className="notice">For a phone-ready QR code, double-click START_PUBLIC_WINDOWS.cmd in your ChargeQuest folder. Keep its window open.</div>}</div>{qr&&<img className="qr" src={qr} alt={`Scan to join room ${code}`}/>}</div>;
}
type ClassroomState=ReturnType<typeof useClassroom>;
function Classroom({demo,initialSession}:{demo:boolean;initialSession:ClientSession}){
  const [role,setRole]=useState(initialSession.role);
  const session={...initialSession,role,participantId:role==='student'?(demo?'preview':initialSession.participantId):null};
  const c=useClassroom(session,demo),s=c.snapshot;
  const disabled=c.busy||(!demo&&c.status!=='Connected');
  const act=(event:string,payload:Record<string,unknown>={})=>{void c.send(event,payload).catch(()=>{});};
  const proposal=c.tutorProposal;
  const stage=stages.find(x=>x.id===s?.stage)??stages[0];
  const showExperiment=s&&!s.questionOpen&&(s.stage==='reveal_rc'||s.stage==='resistance'||s.stage==='lc'||(s.stage==='predict_rc'&&!!s.question));
  return <div className="classroom"><header className="topbar"><Brand/><div className="header-right"><span className={`connection ${c.status==='Reconnecting'?'offline':''}`} role="status"><span className="dot"/>{c.status}</span><span className="role-chip">{role==='host'?'Host console':'Student space'}</span></div></header>
    {demo&&<div className="demo-banner"><span><strong>LOCAL PREVIEW</strong> · One simulated learner. No live room or online AI. Refresh resets this preview.</span><div><button onClick={()=>setRole(role==='host'?'student':'host')}>Switch to {role==='host'?'student':'host'} view ↗</button><button onClick={()=>window.location.reload()}>Reset preview</button></div></div>}
    {c.error&&<div className="error floating-error" role="alert">{c.error}<button aria-label="Dismiss error" onClick={c.clearError}>×</button></div>}
    {!s?<main className="loading card"><h2>{c.status==='Reconnecting'?'Reconnecting to your classroom…':'Opening your classroom…'}</h2><p>Your answers and controls become available when the server confirms the room state.</p><button className="secondary" onClick={()=>go('/join')}>Back to join</button></main>:<>
    <nav className="stage-nav" aria-label="Classroom progress">{stages.map((x,i)=><div key={x.id} className={x.id===s.stage?'current':i<stages.findIndex(a=>a.id===s.stage)?'complete':''}><span>{String(i+1).padStart(2,'0')}</span>{x.short}</div>)}</nav>
    <main className="room-main"><div className="page-heading"><div><span className="eyebrow">CHAPTER {String(stages.findIndex(x=>x.id===s.stage)+1).padStart(2,'0')} / 07 <span className="heading-divider">·</span> ROOM {s.code}</span><h1>{stage.label}</h1><p>{stage.description}</p></div><div className="participant-total"><strong>{s.participants.filter(p=>p.connected).length}</strong><span>students online</span></div></div>
    <div className={role==='host'?'room-grid':'student-layout'}><div className="main-column">
      {s.stage==='lobby'&&<><Invite code={s.code} demo={demo}/><section className="card welcome-card"><span className="eyebrow">BEFORE THE SWITCH CLOSES</span><h2>Your prediction matters.</h2><div className="steps"><div><b>01</b><h3>Think for yourself</h3><p>Choose an answer and explain your reasoning. Responses stay private while voting is open.</p></div><div><b>02</b><h3>Test the idea</h3><p>Follow a shared experiment, then compare your explanation with the evidence.</p></div><div><b>03</b><h3>Try it again</h3><p>Use a new question to check what changed in your thinking.</p></div></div>{role==='student'&&<div className="waiting"><span className="dot"/>You’re here. Waiting for your host to open a question.</div>}</section></>}
      {s.question&&s.stage!=='results'&&<QuestionCard key={s.question.id} question={s.question} c={c} role={role} disabled={disabled}/>}
      {role==='host'&&!s.questionOpen&&c.explanationSamples.length>0&&<section className="card"><span className="eyebrow">ANONYMOUS REASONING · HOST ONLY</span><h2>Listen to the reasoning.</h2><p className="muted">A few shortened, de-identified responses. These are examples, not a diagnosis.</p>{c.explanationSamples.map((text,i)=><blockquote className="reason-example" key={i}>{text}</blockquote>)}</section>}
      {!s.question&&['predict_rc','final_check'].includes(s.stage)&&<section className="card empty-state"><span className="eyebrow">THINK FIRST</span><h2>The next prediction is on its way.</h2><p>{role==='host'?'Open the question using your host controls.':'Your host will open the question shortly.'}</p></section>}
      {showExperiment&&<section className="experiment-section"><div className="section-heading"><h2>The shared experiment</h2><span className="tag">{s.experiment.mode==='lc'?'IDEAL LOSSLESS MODEL':'EQUAL CAPACITORS · RC'}</span></div><ExperimentPanel experiment={s.experiment} tools={s.experimentTools} clockOffsetMs={c.clockOffsetMs} role={role}
        {...(role==='host'&&!disabled?{onControl:(command:'play'|'pause'|'reset')=>act('host:experiment_control',{command}),onParamsChange:(params:typeof s.experiment.params)=>act('host:set_experiment',{mode:s.experiment.mode,params,stopAtFirstZero:s.experiment.stopAtFirstZero}),onStopAtFirstZeroChange:(stopAtFirstZero:boolean)=>act('host:set_experiment',{mode:s.experiment.mode,params:s.experiment.params,stopAtFirstZero})}:{})}/><ProbeReadout c={c}/></section>}
      {s.tutor&&<section className="card tutor-card"><span className="eyebrow">{s.tutor.source==='ai'?'AI GUIDANCE':'GUIDED FALLBACK'}</span><h2>A thought to test</h2><p><strong>Evidence: </strong>{s.tutor.evidence}</p><p>{s.tutor.message}</p></section>}
      {s.stage==='results'&&<Results c={c} role={role} demo={demo}/>}
      {role==='student'&&!s.question&&s.stage!=='lobby'&&s.stage!=='results'&&<p className="muted">The host is guiding the experiment. Your next question will appear here.</p>}
    </div>{role==='host'&&<aside className="side-column"><section className="card host-controls"><span className="eyebrow">YOU GUIDE THE DISCOVERY</span><h2>Classroom controls</h2><label htmlFor="stage">Classroom stage</label><select id="stage" value={s.stage} disabled={disabled} onChange={e=>act('host:set_stage',{stage:e.target.value})}>{stages.map(x=><option key={x.id} value={x.id}>{x.short}</option>)}</select>
      {s.stage==='lobby'&&<button className="primary wide" disabled={disabled} onClick={()=>act('host:set_stage',{stage:'predict_rc'})}>Begin the first prediction →</button>}
      {['predict_rc','resistance','final_check'].includes(s.stage)&&!s.questionOpen&&s.question?.id!==(s.stage==='predict_rc'?'rc_v1':s.stage==='resistance'?'resistance_v1':'final_v1')&&<button className="primary wide" disabled={disabled} onClick={()=>act('host:open_question',{questionId:s.stage==='predict_rc'?'rc_v1':s.stage==='resistance'?'resistance_v1':'final_v1'})}>Open {s.stage==='final_check'?'final check':'prediction'}</button>}
      {s.questionOpen&&<><p className="submission-progress" role="status">{s.submittedCount} responses received</p><button className="primary wide" disabled={disabled} onClick={()=>act('host:close_question')}>Close voting & reveal</button></>}
      {s.stage!=='lobby'&&s.stage!=='results'&&<button className="secondary wide next-stage" disabled={disabled} onClick={()=>act('host:set_stage',{stage:stages[stages.findIndex(x=>x.id===s.stage)+1].id})}>Continue to {stages[stages.findIndex(x=>x.id===s.stage)+1].short} →</button>}
      {s.stage==='resistance'&&!s.questionOpen&&<div className="tool-controls"><button className="secondary wide" disabled={disabled} onClick={()=>act('host:experiment_tool',{requestId:newRequestId(),command:{action:'compare_resistance',values:[100,10]}})}>Compare 100 Ω / 10 Ω</button><button className="secondary wide" disabled={disabled} onClick={()=>act('host:experiment_tool',{requestId:newRequestId(),command:{action:'inspect_time',timeMs:0.5,highlight:'current'}})}>Pin current probe at 0.5 ms</button><button className="text-link" disabled={disabled} onClick={()=>act('host:experiment_tool',{requestId:newRequestId(),command:{action:'clear_tools'}})}>Clear experiment tools</button><small>Manual tools · shared only after server confirmation</small></div>}
      <p className="control-note">You can always choose the next stage manually.</p></section>
      {s.question&&!s.questionOpen&&<section className="card tutor-card"><div className="section-heading"><span className="eyebrow">TEACHING ASSISTANT</span><span className="tag">{proposal?(proposal.source==='ai'?'AI':'FALLBACK'):'READY'}</span></div><h2>Let the answers lead.</h2><p>Look for a possible misconception, then choose the next teaching move.</p><button className="secondary wide" disabled={disabled} onClick={()=>void c.analyze()}>{c.busy?'Working…':'Analyze closed responses'}</button>{proposal&&<><div className="decision"><span className="eyebrow">{proposal.source==='fallback'?'GUIDED FALLBACK':'AI SUGGESTION'}</span><h3>{proposal.misconception}</h3><p><strong>Evidence: </strong>{proposal.evidence}</p><p>{proposal.message}</p>{proposal.followup&&<blockquote>{proposal.followup}</blockquote>}<span className="tag">{proposal.toolCommand?.action??proposal.action}</span></div><button className="primary wide" disabled={disabled} onClick={()=>act('host:apply_tutor',proposal?.proposalId?{proposalId:proposal.proposalId}:{})}>Apply suggestion →</button><small>The server validates and applies this suggestion.</small></>}</section>}
      <section className="card roster"><div className="section-heading"><h2>Your classroom</h2><span className="tag">{s.participants.length}/30</span></div>{!s.participants.length?<p className="muted">Ready when your students are.</p>:<ul>{s.participants.map(p=><li key={p.id}><span className={`avatar ${p.connected?'':'away'}`}>{p.nickname.slice(0,1).toUpperCase()}</span><span>{p.nickname}</span><span className={`dot ${p.connected?'':'gray'}`} aria-label={p.connected?'Online':'Offline'}/></li>)}</ul>}</section>
    </aside>}</div></main></>}
    <footer className="footer"><span>Every prediction is a starting point.</span><span>Temporary room · refresh restores this tab’s session · server restart clears data</span></footer></div>;
}
function QuestionCard({question:q,c,role,disabled}:{question:Question;c:ClassroomState;role:string;disabled:boolean}){
  const existing=c.mySubmissions.find(a=>a.questionId===q.id);
  const [option,setOption]=useState(existing?.optionId??''),[explanation,setExplanation]=useState(existing?.explanation??''),[confidence,setConfidence]=useState(existing?.confidence??50),[saved,setSaved]=useState(false);
  const s=c.snapshot!,open=s.questionOpen;
  // Restore the saved answer on reconnect, without replacing an unsent local edit.
  const [dirty,setDirty]=useState(false);
  useEffect(()=>{if(existing&&!dirty){setOption(existing.optionId??'');setExplanation(existing.explanation);setConfidence(existing.confidence);}},[existing?.submittedAt,dirty]);
  const isSaved=!!existing&&option===(existing.optionId??'')&&explanation===existing.explanation&&confidence===existing.confidence;
  async function submit(){setSaved(false);try{await c.send('student:submit',{questionId:q.id,optionId:q.options.length?option:null,explanation:explanation.trim(),confidence});setDirty(false);setSaved(true);}catch{/* hook renders the actual error */}}
  const readonly=disabled||!open||c.eligible===false;
  return <section className="card question-card"><div className="section-heading"><span className="eyebrow">{q.kind==='followup'?'A QUESTION TO THINK ABOUT':'YOUR INDEPENDENT PREDICTION'}</span><span className={`tag ${open?'live':''}`}>{open?'VOTING OPEN':'VOTING CLOSED'}</span></div><h2>{q.prompt}</h2>
    {role==='host'?<p className="muted">{open?'Students can edit until you close voting. The answer distribution stays hidden.':'Voting has ended. Use the evidence to guide your next step.'}</p>:<form onSubmit={e=>{e.preventDefault();void submit();}}>
      {c.eligible===false&&<div className="notice">You joined after this question opened. Observe this round; you can answer the next one.</div>}
      <fieldset disabled={readonly}><legend className="sr-only">Choose your prediction</legend><div className="options">{q.options.map((o,i)=><label key={o.id} className={option===o.id?'option selected':'option'}><input type="radio" name={q.id} value={o.id} checked={option===o.id} onChange={()=>{setOption(o.id);setDirty(true);setSaved(false);}}/><span className="option-letter">{String.fromCharCode(65+i)}</span><span>{o.label}</span><span className="radio-mark"/></label>)}</div>
      <label htmlFor={`reason-${q.id}`}>{q.kind==='final'?'Why? Also explain why an ideal inductor, disconnected at the first zero-current point, gives a different result.':'What makes you think so?'}</label><textarea id={`reason-${q.id}`} value={explanation} maxLength={500} required={q.requiresExplanation} placeholder="Your reasoning matters more than a perfect answer…" onChange={e=>{setExplanation(e.target.value);setDirty(true);setSaved(false);}}/><div className="char-count">{explanation.length}/500</div><label htmlFor={`confidence-${q.id}`} className="range-label">How confident do you feel? <strong>{confidence}%</strong></label><input id={`confidence-${q.id}`} type="range" min="0" max="100" value={confidence} onChange={e=>{setConfidence(Number(e.target.value));setDirty(true);setSaved(false);}}/><div className="range-ends"><span>Still exploring</span><span>Quite certain</span></div></fieldset>
      <div className="submit-row"><span className="saved" role="status">{isSaved||saved?'✓ Response saved':existing?'You have unsaved changes':open?'Only your response is visible to you.':'This question is closed.'}</span><button className="primary" disabled={readonly||(!option&&q.options.length>0)||(q.requiresExplanation&&!explanation.trim())||isSaved}>{c.busy?'Saving…':existing?'Update prediction':'Save prediction'} <Arrow/></button></div>
    </form>}
    {!open&&s.aggregate&&<div className="distribution"><div className="section-heading"><h3>The class prediction</h3><span>{s.aggregate.submitted} / {s.aggregate.eligible} submitted</span></div>{q.options.length===0?<p>{s.aggregate.submitted} written responses collected.</p>:q.options.map(o=>{const count=s.aggregate!.counts[o.id]??0;const pct=s.aggregate!.submitted?count/s.aggregate!.submitted*100:0;return <div className="bar-row" key={o.id}><span>{o.label}</span><div className="bar-track"><div style={{width:`${pct}%`}}/></div><strong>{count} <small>({Math.round(pct)}%)</small></strong></div>;})}{!s.aggregate.submitted&&<p className="muted">No responses yet. You can continue manually.</p>}</div>}
  </section>;
}
function ProbeReadout({c}:{c:ClassroomState}){
  const s=c.snapshot!,t=s.experimentTools?.focusTime;
  if(t===undefined||t===null)return null;
  const values=s.experimentTools?.comparison?.values??[s.experiment.params.R];
  return <div className="card mobile-probe"><span className="eyebrow">PINNED MODEL PROBE · {(t*1000).toFixed(3)} ms</span><p>Calculated values at the same physical time.</p><table><thead><tr><th scope="col">Quantity</th>{values.map(R=><th scope="col" key={R}>{R} Ω</th>)}</tr></thead><tbody>{(['vA','vB','i','heat'] as const).map(k=><tr key={k}><th scope="row">{({vA:'Voltage A (V)',vB:'Voltage B (V)',i:'Current (mA)',heat:'Heat (mJ)'})[k]}</th>{values.map(R=>{const sample=(s.experiment.mode==='rc'?sampleRC:sampleLC)({...s.experiment.params,R},t);return <td key={R}>{(sample[k]*(k==='i'||k==='heat'?1000:1)).toFixed(2)}</td>;})}</tr>)}</tbody></table></div>;
}
function Results({c,role,demo}:{c:ClassroomState;role:string;demo:boolean}){
  const r=c.results;
  if(!r)return <section className="card"><h2>Waiting for the session report.</h2><p>Results will appear when the server sends the confirmed report.</p></section>;
  const pct=(n:number)=>`${Math.round(n/r.paired.n*100)}%`;
  return <section className="card results"><span className="eyebrow">{demo?'SIMULATED PREVIEW RESULTS':'THIS SESSION’S CONCEPT CHECK'}</span><h2>A little more clarity.</h2><p>Compare only learners who answered both the first and final questions.</p><div className="result-stats"><div><span>Paired responses</span><strong>{r.paired.n}</strong></div><div><span>First prediction</span><strong>{r.paired.n?pct(r.paired.beforeCorrect):'—'}</strong></div><div><span>Final check</span><strong>{r.paired.n?pct(r.paired.afterCorrect):'—'}</strong></div></div>{!r.paired.n&&<div className="notice">Insufficient responses for a paired comparison.</div>}<p className="muted">{r.participantCount} participants · Different questions checking a shared concept. This does not establish long-term mastery.</p>{role==='student'&&<><h3>Your reflection</h3>{r.myAnswers.length?r.myAnswers.map(a=><article className="answer-result" key={a.questionId}><div className="section-heading"><strong>{a.questionId==='final_v1'?'Final check':a.questionId==='rc_v1'?'First prediction':'Resistance prediction'}</strong><span className="tag">{a.correct===undefined?'Submitted':a.correct?'Correct':'Review this idea'}</span></div><p>{a.explanation}</p>{a.feedback&&<p className="notice">Formative feedback: {a.feedback}</p>}</article>):<p>You haven’t submitted an answer in this session.</p>}</>}</section>;
}
